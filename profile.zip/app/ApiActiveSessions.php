<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApiActiveSessions extends Model
{
	protected $table = 'api_active_sessions';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'api_version',
		'device_id',
		'mac_address',
		'ip_address'
    ];
}
