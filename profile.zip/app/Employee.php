<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
	protected $table = 'employees';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'employee_custom_id',
		'employee_type_id',
		'user_id',
		'doj',
		'employee_address_id',
		'is_compliant',
		'status'
    ];
}