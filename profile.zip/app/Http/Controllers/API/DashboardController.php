<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\EmployeeEmploymentHistory;
use App\EmployerEmployeeNetwork;
use Illuminate\Http\Request;
use App\TaskHistory;
use App\OrderTask;
use App\Employer;
use App\Employee;
use App\ApiKey;
use App\Survey;
use App\UserNotification;
use App\Order;
use Auth;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        try {

            $allResponse = '';

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $empIds = Employee::where('user_id', Auth::id())->select('id')->first();
                $empHistory = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $empIds->id)->orderBy('updated_at', 'desc')->first();
        
                $registered_employees = EmployeeEmploymentHistory::select('employee_id')
                    ->where('employed_by', $empHistory->employed_by)
                    ->count();

                $verified_employees = EmployeeEmploymentHistory::select('is_verified')
                    ->where('employed_by', $empHistory->employed_by)
                    ->where('is_verified', 'Y')
                    ->count();

                $pending_verifications = Order::select('orders.id')
                    ->join('employers', 'orders.employer_id', '=', 'employers.id')
                    ->where('employers.id', $empHistory->employed_by)
                    ->where('orders.status', '!=', 'COMPLETE')
                    ->count();

                $ordertasks = OrderTask::select('order_tasks.id')
                    ->where('employer_id', $empHistory->employed_by)
                    ->get();

                $count = 0;
                foreach ($ordertasks as $key => $ordertask) {
                    $taskhistory = TaskHistory::select('severity')->orderBy('id', 'desc')->where('task_id', $ordertask->id)->first();
                    if($taskhistory->severity == 'RED'){
                        $count = $count + 1;
                    }
                }

                $red_cases = $count;

                $response = response()->json([
                    'response' => [
                        'status' => 200,
                        'data' => [
                            'registered_employees' => $registered_employees,
                            'verified_employees' => $verified_employees,
                            'pending_verifications' => $pending_verifications,
                            'red_cases' => $red_cases,
                        ],
                        'message' => 'Success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function get_candidates($value='')
    {
        try {

            $user = Auth::user();
            $allResponse = '';

            $empIds = Employee::where('user_id', Auth::id())->select('id')->first();
            $empHistory = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $empIds->id)->orderBy('updated_at', 'desc')->first();

            if(isset($user) && !empty($user->id)){
                
                $employer = Employer::select('id')->where('id', $empHistory->employer_id)->first();

                $networks = EmployerEmployeeNetwork::where([
                    'employer_employee_network.employer_id' => $empHistory->employed_by,
                    'employer_employee_network.status' => 'A'
                    ])
                    ->leftJoin('employees', 'employer_employee_network.its_employee', '=', 'employees.id')
                    ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                    ->leftJoin('user_pics', 'employees.id', '=', 'user_pics.employee_id')
                    ->leftJoin('employee_employment_history', 'employees.id', '=', 'employee_employment_history.employee_id')
                    ->leftJoin('employee_types', 'employees.employee_type_id', '=', 'employee_types.id')
                    ->select('employees.email as emp_email', 'users.id as user_id', 'users.mobile', 'employees.status as emp_status', 'employees.id as employee_id', 'employees.status as verified', 'users.first_name', 'users.middle_name', 'users.last_name', 'users.dob', 'user_pics.photo_url', 'employee_types.type', 'employee_employment_history.employment_start', 'employee_employment_history.employment_stop', 'employee_employment_history.verification_date')
                    ->groupBy('employees.id')
                    ->orderBy('employer_employee_network.id', 'desc')
                    ->get();
                    // ->paginate(15);

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $networks,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- employer-profile <V1> <DEVICE_ID> <200> Profile Successfully get.',
            ]));

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'failed',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function notification(Request $request){
        try {

            $allResponse = '';
            $employee = Employee::where('user_id', Auth::id())->first();
            $empInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employee->id)->first();
            $employer = Employer::find($empInfo->employed_by);
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){
                $convert = \DB::raw("DATE_FORMAT(created_at, '%Y-%m-%d %h:%m:%s') as date");

                $messages = UserNotification::select('id','nf_to','nf_message',$convert,'nf_action_url','is_seen')
                            ->where('nf_to',$employer->id)
                            ->orderBy('created_at','desc')
                            ->get();
                $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => [
                                'messages' => $messages
                            ],
                            'message'   => 'success'
                                            ]
                    ], 200);

        
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            $allResponse = ' ';
            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }            
    }

    public function notificationCount(Request $request){
        try {

                $allResponse = '';
                $employee = Employee::where('user_id', Auth::id())->first();
                $empInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employee->id)->first();
                $employer = Employer::find($empInfo->employed_by);
                $apikey = ApiKey::where([
                    'api_key' => $request->api_key,
                    'status' => 'A'
                ])->first();

                if(isset($apikey) && !empty($apikey->id)){
                    $messages = UserNotification::select('id')
                                ->where([
                                    'is_seen'=>'Y',
                                    'nf_to'=>$employer->id
                                ])
                                ->count();
                    $response = response()->json([
                            'response' => [
                                'status'    => 200,
                                'data'      => [
                                    'messages' => $messages 
                                ],
                                'message'   => 'success'
                                                ]
                        ], 200);

            
                    return $response;

                } else {                        
                    
                    $response = response()->json([
                        'response' => [
                            'status'    => 400,
                            'data'      => '',
                            'message'   => 'Api Key Not Verified;'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }

         }catch (\Exception $e){
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            $allResponse = ' ';
            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function seenNotification(Request $request){
        
            try {

                $allResponse = '';
                $apikey = ApiKey::where([
                    'api_key' => $request->api_key,
                    'status' => 'A'
                ])->first();

                if(isset($apikey) && !empty($apikey->id)){
                    $seen = UserNotification::where('id',$request->id)
                            ->update(['is_seen' => 'Y']);
                    $seen = UserNotification::select('id','nf_message','nf_action_url','is_seen')
                            ->where('id',$request->id)->first();
                    $message = $seen->nf_action_url;
                    $response = response()->json([
                            'response' => [
                                'status'    => 200,
                                'data'      => [
                                    'messages' => $message
                                ],
                                'message'   => 'success'
                                                ]
                        ], 200);

            
                    return $response;

                } else {                        
                    
                    $response = response()->json([
                        'response' => [
                            'status'    => 400,
                            'data'      => '',
                            'message'   => 'Api Key Not Verified;'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }

         }catch (\Exception $e){
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            $allResponse = ' ';
            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}
