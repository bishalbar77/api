<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\ApiActiveSessions;
use App\DocumentType;
use Auth;
use Log;


class DocumentTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $allResponse = json_encode($request->all());
        $actsession = ApiActiveSessions::where('device_id', $request->device_id)->first();

        if(isset($actsession) && !empty($actsession)){
            if($actsession->status == 'I'){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => '',
                        'messege' => 'You are not allowed to access.'
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
        } else {
            $actsession = new ApiActiveSessions;
            $actsession->api_version = 'v1';
            $actsession->device_id = $request->device_id;
            $actsession->mac_address = $request->mac_address;
            $actsession->ip_address = $request->ip();
            $actsession->save();
        }

        $doctypes = DocumentType::where([
            'status' => 'A',
            'source' => $request->source
        ])->select([
            'id',
            'name'
        ])->get();

        $response = response()->json([
            'response' => [
                'status'    => 200,
                'data'      => $doctypes,
                'messege'   => 'success'
            ]
        ], 200);

        \LogActivity::addToLog($allResponse, $response);
                
        return $response;
    }
}
