<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use AWS;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use Aws\Exception\AwsException;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use App\EmployeeEmploymentHistory;
use App\EmployerEmployeeNetwork;
use App\EmployeeLookupHistory;
use App\ApiActiveSessions;
use App\DocumentType;
use App\EmployeeType;
use App\EmployeeReview;
use App\VerificationType;
use App\UserWebProfile;
use App\UserAddress;
use App\DataSource;
use App\Employee;
use App\Employer;
use App\UserPref;
use App\UserPic;
use App\UserDoc;
use App\User;
use App\ApiKey;
use App\Uid;
use Geocoder;
use DB;
use Log;
use App\B2bUser;

class EmployeeController extends Controller
{
    /**
     * Create a new user instance after a valid registration.
     *
     * @param array $data
     * @return
     */

    public function IsBase64($data) {
        $decoded_data = base64_decode($data, true);
        $encoded_data = base64_encode($decoded_data);
        if ($encoded_data != $data) return false;
        else if (!ctype_print($decoded_data)) return false;

        return true;
    }

    public function does_url_exists($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($code == 200) {
            $status = true;
        } else {
            $status = false;
        }
        curl_close($ch);
        return $status;
    }

    function add_employers_employee(Request $request)
    {
        try{


            $allResponse = $request->al();
            $user = Auth::user();                
            $employer = Employer::select('id')->where('user_id', $user->id)->first();
            $source = DataSource::select('source_name')->where('id', $user->data_source_id)->first();

            $validator = Validator::make($request->all(), [
                'mobile' => 'required|unique:users,mobile',
                'first_name' => 'required',
                'last_name' => 'required',
                'dob' => 'required',
                'gender' => 'required',
                'document_number' => 'required',
                'employee_types_id' => 'required',
                'document_types_id' => 'required',               
                'latitude' => 'required',                
                'longitude' => 'required',                
                'document' => 'required',                
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $user = User::where([
                'mobile' => $this->trim_mobile($request->mobile)
            ])->first();

            if(isset($user) && !empty($user->id)){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => $user,
                        'message' => 'You are Already Registered.'
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            if(!empty($request->email)){
                $userEmail = User::where([
                    'email' => $request->email
                ])->first();

                if(isset($userEmail) && !empty($userEmail->id)){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => $userEmail,
                            'message' => 'You are Already Registered.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            }

            if($this->IsBase64($request->document) != true){
                if($this->does_url_exists($request->document) == true){
                    $imageData = 'data: png;base64,'.base64_encode(file_get_contents($request->document));
                } else {
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => '',
                            'message' => 'Please Pass Valid document url.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            } else {
                if($this->IsBase64($request->document) == true){
                    $imageData = $request->document;
                } else {
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => '',
                            'message' => 'Please Pass Valid document.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            }

            $iv = 'dddddddddddddddd';            

            $checkExistEmp = UserDoc::where([
                'doc_type_id' => $request->document_types_id,
                // 'doc_number' => bin2hex(openssl_encrypt($request->document_number,'AES-128-CBC', 'TrueHelpDocs', OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv)),
                'doc_number' => $request->document_number,
                'status' => 'A',
            ])->select([
                'id',
                'user_id'
            ])->first();

            // print_r($checkExistEmp);exit;

            if(isset($checkExistEmp) && !empty($checkExistEmp->id)){
                $user = User::where([
                    'id' => $checkExistEmp->user_id
                ])->first();

                $employee_info = Employee::where('employees.user_id', $checkExistEmp->user_id)->first();

                $employerInfo = EmployeeEmploymentHistory::where('employee_employment_history.employee_id', $employee_info->id)
                    ->where('employee_employment_history.employment_stop', '=', NULL)
                    ->leftJoin('employers', 'employers.id', '=', 'employee_employment_history.employed_by')
                    ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                    ->select('users.first_name','users.middle_name','users.last_name')
                    ->first();

                $messege = $user->first_name.' '.$user->middle_name.' '.$user->last_name.' Already Employed with '.$employerInfo->first_name.' '.$employerInfo->middle_name.' '.$employerInfo->last_name;

                $user->employee_id = $employee_info->id;

                $response = response()->json([
                    'response' => [
                        'status' => 201,
                        'data' => $user,
                        'message' => $messege,
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $otp = rand(1000, 9999);

            DB::beginTransaction();      

            $datasource = new DataSource;
            $datasource->source_name = $source->source_name;
            $datasource->campaign_name = $request->campaign_name ?? '';
            $datasource->ip_address = $request->ip();
            $datasource->save();            

            $user = new User;
            $user->email = $request->email ?? '';
            $user->password = Hash::make('secret');
            $user->mobile = $this->trim_mobile($request->mobile);
            $user->mobile_otp = $otp;
            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;
            $user->co_name = $request->care_of;
            $user->dob = date('Y-m-d', strtotime($request->dob));
            $user->gender = $request->gender;
            $user->data_source_id = $datasource->id;
            $user->save();

            $employee = new Employee;
            $employee->employee_custom_id = rand(1000,9999);
            $employee->employee_type_id = $request->employee_types_id;
            $employee->user_id = $user->id;
            $employee->doj = $request->doj ? date('Y-m-d', strtotime($request->doj)) : date('Y-m-d');
            $employee->save();

            $network = new EmployerEmployeeNetwork;
            $network->employer_id = $employer->id;
            $network->its_employee = $employee->id;
            $network->status = 'A';
            $network->save();            

            $lookup = new EmployeeLookupHistory;
            $lookup->employee_id = $employee->id;
            $lookup->doc_type_id = $request->document_types_id;
            $lookup->employee_type_id = $request->employee_types_id;
            $lookup->latitude = $request->latitude;
            $lookup->longitude = $request->longitude;
            $lookup->ip_address = $request->ip();
            $lookup->browser_info = $request->header('User-Agent');
            $lookup->lookup_by = $employer->id;
            $lookup->save();

            $userpref = new UserPref;
            $userpref->user_id = $user->id;
            $userpref->lang = $request->language == 'hi' ? 2 : 1;
            $userpref->save();
            
            $image_parts = explode(";base64,", $imageData);

            $image_base64 = base64_decode($image_parts[1]);
            
            $file = storage_path('documents/'.uniqid().'.png');

            if(file_put_contents($file, $image_base64)) {
                $s3 = AWS::createClient('s3');
                $fileData = $s3->putObject(array(
                    'Bucket'        => 'cdn.gettruehelp.com',
                    'Key'           => 'documents/'.md5(rand(1000000000,999999999999)).'.png',
                    'SourceFile'    => $file,
                    'StorageClass'  => 'STANDARD',
                    'ContentType'   => 'image/png',
                    'ACL'           => 'public-read',
                ));

                if(!empty($fileData)){
                    $userdoc = new UserDoc;
                    $userdoc->user_id = $user->id;
                    $userdoc->doc_type_id = $request->document_types_id;
                    $userdoc->cosmos_id = rand(1,9999999);
                    $userdoc->doc_number = $request->document_number;
                    $userdoc->doc_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                    $userdoc->uploaded_by = $user->id;
                    $userdoc->save();
                }
            }

            $user->employee_id = $employee->id;

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $user,
                    'message'   => 'Registered successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function upload_employee_document(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            $user = Auth::user();                
            // $employer = Employer::select('id')->where('user_id', $user->id)->first();
            // $employee = Employee::select('id')->where('user_id', $request->user_id)->first();

            $validator = Validator::make($request->all(), [
                'document_number' => 'required',
                'document_types_id' => 'required',               
                'user_id' => 'required',               
                'document' => 'required',            
                'source' => 'in:B2B,B2C,BOT'            
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            DB::beginTransaction();

            if($request->source == 'BOT'){
                $imageData = 'data: png;base64,'.base64_encode(file_get_contents($request->document));
            } else {
                $imageData = $request->document;
            }
            
            $image_parts = explode(";base64,", $imageData);

            $image_base64 = base64_decode($image_parts[1]);
            
            $file = storage_path('documents/'.uniqid().'.png');

            if(file_put_contents($file, $image_base64)) {
                $s3 = AWS::createClient('s3');
                $fileData = $s3->putObject(array(
                    'Bucket'        => 'cdn.gettruehelp.com',
                    'Key'           => 'documents/'.md5(rand(1000000000,999999999999)).'.png',
                    'SourceFile'    => $file,
                    'StorageClass'  => 'STANDARD',
                    'ContentType'   => 'image/png',
                    'ACL'           => 'public-read',
                ));

                if(!empty($fileData)){
                    $userdoc = new UserDoc;
                    $userdoc->user_id = $request->user_id;
                    $userdoc->doc_type_id = $request->document_types_id;
                    $userdoc->cosmos_id = rand(1,9999999);
                    $userdoc->doc_number = $request->document_number;
                    $userdoc->doc_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                    $userdoc->uploaded_by = $user->id;
                    $userdoc->save();
                }
            }

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $request->user_id,
                    'message'   => 'Uploaded successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function upload_employee_photo(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());
            $user = Auth::user();                
            // $employer = Employer::select('id')->where('user_id', $user->id)->first();
            // $employee = Employee::select('id')->where('id', $request->employee_id)->first();

            $validator = Validator::make($request->all(), [             
                'employee_id' => 'required',               
                'photo' => 'required',
                'source' => 'in:B2B,B2C,BOT'          
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            DB::beginTransaction();   

            if($request->source == 'BOT'){
                $imageData = 'data: png;base64,'.base64_encode(file_get_contents($request->photo));
            } else {
                $imageData = $request->photo;
            }
            
            $image_parts = explode(";base64,", $imageData);

            $image_base64 = base64_decode($image_parts[1]);
            
            $file = storage_path('profile/'.uniqid().'.png');

            if(file_put_contents($file, $image_base64)) {
                $s3 = AWS::createClient('s3');
                $fileData = $s3->putObject(array(
                    'Bucket'        => 'cdn.gettruehelp.com',
                    'Key'           => 'img/'.md5(rand(1000000000,999999999999)).'.png',
                    'SourceFile'    => $file,
                    'StorageClass'  => 'STANDARD',
                    'ContentType'   => 'image/png',
                    'ACL'           => 'public-read',
                ));

                if($fileData){
                    $userpic = new UserPic;
                    $userpic->employee_id = $request->employee_id;
                    $userpic->photo_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                    $userpic->uploaded_by = $user->id;
                    $userpic->save();
                }
            }

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $request->employee_id,
                    'message'   => 'Uploaded successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function update_employment_info(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            $user = Auth::user();                
            $employer = Employer::select('id')->where('user_id', $user->id)->first();
            $employee = Employee::select('id')->where('id', $request->employee_id)->first();

            $validator = Validator::make($request->all(), [
                'employee_id' => 'required',
                'salary' => 'required',
                'employment_start' => 'required'        
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }          

            $history = new EmployeeEmploymentHistory;
            $history->employee_id = $employee->id;
            $history->employed_by = $employer->id;
            $history->salary = $request->salary;
            $history->employment_start = $request->employment_start;
            $history->save();

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $employee,
                    'message'   => 'Updated successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    private function trim_mobile($mobile){
        
        $mobile = str_replace("+","", $mobile);
        
        $length = strlen($mobile);
        
        if($length == 11){
            $mobile = substr($mobile, 1);
        } elseif($length == 12) {
            $mobile = substr($mobile, 2);                
        } elseif($length == 13) {
            $mobile = substr($mobile, 3);                
        }

        return $mobile;
    }

    public function otp($phone, $otp)
    {
        try{

            $SnSclient          = new SnsClient([
                'region'        => 'us-east-1',
                'version'       => '2010-03-31',
                'credentials'   => [
                'key'           => 'AKIA4SH5KM3GHHQL5CUF',
                'secret'        => 'tqp57AghAQCK13orjlYugUHrQ/BecwQrgod/AVfx',
                ]
            ]);

            $result = $SnSclient->publish([
                'Message'     => $otp.' is your TrueHelp OTP code. DO NOT share the OTP with ANYONE.',
                'PhoneNumber' => $phone,
            ]);

            return response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'OTP Sent to Registered Number.',
                ]
            ], 200);
            
        } catch (\Exception $e) {
            return response()->json([
                'response' => [
                    'status'    => '500',
                    'data'      => "",
                    'message'   => $e->getMessage()
                ]
            ], 500);
        }
    }

    public function employee_data(Request $request){
        
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'api_key' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $valid_api = ApiKey::where(['api_key' => $request->api_key, 'status' => 'A'])->first();

            if(isset($valid_api) && !empty($valid_api->id)){

                $employer = Employee::select([
                    'users.first_name',
                    'users.middle_name',
                    'users.last_name',
                    'users.alias',
                    'users.co_name as care_of',
                    'employee_types.type',
                    'users.dob',
                    'users.gender',
                    'languages.code as lang',
                    'employees.id as employee_id',
                    'employee_employment_history.is_verified as is_employed',
                    'employee_employment_history.employed_by as employer_id',
                    'employees.doj',
                    'user_addresses.id as address_id',
                    'users.user_web_profile_id as web_profie_id'
                    ])
                ->leftJoin('users','employees.user_id','=','users.id')
                ->leftJoin('user_prefs','users.id','=','user_prefs.user_id')
                ->leftJoin('languages','user_prefs.lang','=','languages.id')
                ->leftJoin('employee_employment_history','employee_employment_history.employee_id','=','employees.id')
                ->leftJoin('user_addresses','user_addresses.employee_id','=','employees.id')
                ->leftJoin('employee_types','employee_types.id','=','employees.employee_type_id')
                ->where([
                    'mobile' => $this->trim_mobile($request->mobile)
                ])->first();

                if(isset($employer) && !empty($employer->employer_id)){

                    Log::info(json_encode([
                        'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 200 Success.',
                    ]));

                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => $employer,
                            'message'   => 'success',
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }

                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 200 No data found for number '.$request->mobile,
                ]));

                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'No data found for number '.$request->mobile,
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                    
                return $response;

            } else {
                
                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 403 Unauthorized access.',
                ]));
                $response = response()->json([
                    'response' => [
                        'status'    => 403,
                        'data'      => '',
                        'message'   => 'Unauthorized access.',
                    ]
                ], 403);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function add_employee_scan(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());
            $user = Auth::user();                
            $employer = Employer::select('id')->where('user_id', $user->id)->first();
            $source = DataSource::select('source_name')->where('id', $user->data_source_id)->first();

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'employee_types_id' => 'required',
                'document_types_id' => 'required',
                'scan_data' => 'required',
                'latitude' => 'required',                
                'longitude' => 'required',          
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $user = User::where([
                'mobile' => $this->trim_mobile($request->mobile)
            ])->first();

            if(isset($user) && !empty($user->id)){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => $user,
                        'message' => 'You are Already Registered.'
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $xml        = simplexml_load_string($request->scan_data);

            $iv = 'dddddddddddddddd';

            $checkExistEmp = UserDoc::where([
                'doc_type_id' => $request->document_types_id,
                // 'doc_number' => bin2hex(openssl_encrypt($xml['uid'],'AES-128-CBC', 'TrueHelpDocs', OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv)),
                'doc_number' => $xml['uid'],
                'status' => 'A',
            ])->select([
                'id',
                'user_id'
            ])->first();

            if(isset($checkExistEmp) && !empty($checkExistEmp->id)){
                $user = User::where([
                    'id' => $checkExistEmp->user_id
                ])->first();

                $employee_info = Employee::where('employees.user_id', $checkExistEmp->user_id)->first();

                $employerInfo = EmployeeEmploymentHistory::where('employee_employment_history.employee_id', $employee_info->id)
                    ->where('employee_employment_history.employment_stop', '=', NULL)
                    ->leftJoin('employers', 'employers.id', '=', 'employee_employment_history.employed_by')
                    ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                    ->select('users.first_name','users.middle_name','users.last_name')
                    ->first();

                $messege = $user->first_name.' '.$user->middle_name.' '.$user->last_name.' Already Employed with '.$employerInfo->first_name.' '.$employerInfo->middle_name.' '.$employerInfo->last_name;

                $user->employee_id = $employee_info->id;

                $response = response()->json([
                    'response' => [
                        'status' => 201,
                        'data' => $user,
                        'message' => $messege,
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $otp = rand(1000, 9999);

            DB::beginTransaction();      

            $datasource = new DataSource;
            $datasource->source_name = $source->source_name;
            $datasource->campaign_name = $request->campaign_name ?? '';
            $datasource->ip_address = $request->ip();
            $datasource->save();
            
            $nameArr    = explode(" ", $xml['name']);
            $fname      = (isset($nameArr[0]) && !empty($nameArr[0])) ? $nameArr[0] : '';
            $mname      = (isset($nameArr[1]) && !empty($nameArr[1])) ? $nameArr[1] : '';
            $lname      = (isset($nameArr[2]) && !empty($nameArr[2])) ? $nameArr[2] : '';

            $user = new User;
            $user->email = $request->email ?? '';
            $user->password = Hash::make('secret');
            $user->mobile = $this->trim_mobile($request->mobile);
            $user->mobile_otp = $otp;
            $user->first_name = $fname;
            $user->middle_name = $mname;
            $user->last_name = $lname;
            $user->co_name = $xml['co'] ?? '';
            $user->dob = $xml['dob'] ? date('Y-m-d', strtotime($xml['dob'])) : '';
            $user->gender = $xml['gender'] ?? '';
            $user->data_source_id = $datasource->id;
            $user->save();

            $employee = new Employee;
            $employee->employee_custom_id = rand(1000,9999);
            $employee->employee_type_id = $request->employee_types_id;
            $employee->user_id = $user->id;
            $employee->doj = $request->doj ? date('Y-m-d', strtotime($request->doj)) : date('Y-m-d');
            $employee->save();

            $network = new EmployerEmployeeNetwork;
            $network->employer_id = $employer->id;
            $network->its_employee = $employee->id;
            $network->status = 'A';
            $network->save();            

            $lookup = new EmployeeLookupHistory;
            $lookup->employee_id = $employee->id;
            $lookup->doc_type_id = $request->document_types_id;
            $lookup->latitude = $request->latitude;
            $lookup->longitude = $request->longitude;
            $lookup->ip_address = $request->ip();
            $lookup->browser_info = $request->header('User-Agent');
            $lookup->lookup_by = $employer->id;
            $lookup->save();

            $address = new UserAddress;
            $address->employee_id = $employee->id;
            $address->employer_id = $employer->id;
            $address->type = 'PERMANENT';
            $address->street_addr1 = $xml['house'] ?? '';
            $address->street_addr2 = $xml['street'] ?? '';
            $address->village = $xml['loc'] ?? '';
            $address->post_office = $xml['po'] ?? '';
            $address->police_station = $xml['subdist'] ?? '';
            $address->district = $xml['dist'] ?? '';
            $address->city = $xml['vtc'] ?? '';
            $address->state = $xml['state'] ?? '';
            $address->pincode = $xml['pc'] ?? '';
            $address->country = 'India';
            $address->save();

            $userpref = new UserPref;
            $userpref->user_id = $user->id;
            $userpref->lang = $request->language == 'hi' ? 2 : 1;
            $userpref->save();

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $user,
                    'message'   => 'Registered successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function employee_profile($employee_id)
    {
        try{
            $allResponse = '';
            $employee = Employee::select('users.id as user_id', 'users.first_name', 'users.middle_name', 'users.last_name', 'users.mobile', 'users.dob', 'users.gender', 'employee_types.type', 'employee_employment_history.salary', 'employee_employment_history.employment_start')
                ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                ->leftJoin('employee_types', 'employees.employee_type_id', '=', 'employee_types.id')
                ->leftJoin('employee_employment_history', 'employees.id', '=', 'employee_employment_history.employee_id')
                ->where('employees.id', $employee_id)
                ->first();

            $user = User::find($employee->user_id);
            
            $address = UserAddress::where(['employee_id' => $employee_id, 'status' => 'A'])->get();
            $user_pics = UserPic::select('photo_url', 'is_verified')->where('employee_id', $employee_id)->get();
            $user_docs = UserDoc::select('document_types.name as document_name', 'user_docs.doc_url')
                ->leftJoin('document_types', 'user_docs.doc_type_id', '=', 'document_types.id')
                ->where('user_docs.user_id', $employee->user_id)->get();

            $employment_histories = EmployeeEmploymentHistory::select('users.first_name', 'users.middle_name', 'users.last_name', 'employee_employment_history.salary', 'employee_employment_history.employment_start', 'employee_employment_history.employment_stop', 'employee_employment_history.is_verified')
                ->leftJoin('employers', 'employee_employment_history.employed_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->where('employee_employment_history.employee_id', $employee_id)->get();

            $employee_lookup_histories = EmployeeLookupHistory::select('users.first_name', 'users.middle_name', 'users.last_name', 'employee_lookup_histories.latitude', 'employee_lookup_histories.longitude', 'employee_lookup_histories.created_at', 'employee_types.type as employee_type', 'document_types.name as document_type')
                ->leftJoin('employers', 'employee_lookup_histories.lookup_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->leftJoin('employee_types', 'employee_lookup_histories.employee_type_id', '=', 'employee_types.id')
                ->leftJoin('document_types', 'employee_lookup_histories.doc_type_id', '=', 'document_types.id')
                ->where('employee_lookup_histories.employee_id', $employee_id)->get();

            $employee_reviews = EmployeeReview::select('users.first_name', 'users.middle_name', 'users.last_name', 'employee_reviews.rating', 'employee_reviews.review')
                ->leftJoin('employers', 'employee_reviews.reviewed_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->where(['employee_reviews.employee_id' => $employee_id, 'employee_reviews.status' => 'A'])->get();

            $verification_types = VerificationType::select('name', 'amount', 'icon_url', 'description')
                ->where(['status' => 'A', 'source' => 'B2C'])->get();

            $user_web_profiles = UserWebProfile::select('fb_connection_id', 'li_connection_id', 'twtr_connection_id')
                ->where(['id' => $user->user_web_profile_id])->first();

            $data['employee'] = $employee;
            $data['address'] = $address;
            $data['user_pics'] = $user_pics;
            $data['user_docs'] = $user_docs;
            $data['employment_histories'] = $employment_histories;
            $data['employee_lookup_histories'] = $employee_lookup_histories;
            $data['employee_reviews'] = $employee_reviews;
            $data['verification_types'] = $verification_types;
            $data['user_web_profiles'] = $user_web_profiles;

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $data,
                    'message'   => 'success'
                ]
            ], 200);
            
            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        
        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    function remove_network_employee(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            DB::beginTransaction();

            $employer = Employer::where('user_id', Auth::id())->first();

            $network = EmployerEmployeeNetwork::where([
                'employer_id' => $employer->id,
                'its_employee' => $request->employee_id
            ])->first();

            if(isset($network->id)){
                $network->status = 'I';
                $network->save();
            }

            $employementhistory = EmployeeEmploymentHistory::where([
                'employee_id' => $request->employee_id,
                'employed_by' => $employer->id
            ])->first();
            
            if(isset($employementhistory->id)){
                $employementhistory->employment_stop = date('Y-m-d', strtotime($request->employment_stop));
                $employementhistory->save();
            }

            $employeereview = new EmployeeReview;
            $employeereview->employee_id = $request->employee_id;
            $employeereview->rating = $request->rating;
            $employeereview->review = $request->review;
            $employeereview->status = 'I';
            $employeereview->reviewed_by = Auth::id();
            $employeereview->save();

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Removed successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function change_password(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'old_password' => 'required',
                'new_password' => 'required',
                'confirm_password' => 'required'     
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $b2b_user = B2bUser::where('user_id', Auth::id())->first();

            if($request->new_password != $request->confirm_password){
                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'New Password and Confirm Password Not Matched'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                    
                return $response;
            }

            if(md5($request->old_password) != $b2b_user->password){
                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Old Password Not Matched'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                    
                return $response;
            }

            DB::beginTransaction();

            $b2b_user->password = md5($request->new_password);
            $b2b_user->save();

            DB::commit();
            
            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Password Changed successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}
