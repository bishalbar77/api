<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use AWS;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use Aws\Exception\AwsException;
use App\EmployerEmployeeNetwork;
use App\EmployeeEmploymentHistory;
use App\Employee;
use App\Employer;
use App\UserPic;
use App\User;
use App\ApiKey;
use App\UserPref;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Log;
use DB;

class EmployerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update_employer_profile(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());
            
            $user = User::select('id','email','mobile','first_name','middle_name','last_name','alias','co_name','dob','gender','phone')->where('id', Auth::id())->first();
            $employer = Employer::select('id','email','b2b_company_name','b2b_gst_no','b2b_pan_no','b2b_website')->where('user_id', $user->id)->first();
            $userpics = UserPic::select('id','photo_url')->where('employer_id', $employer->id)->first();

            $validator = Validator::make($request->all(), [
                'email' => 'required',
                'mobile' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'dob' => 'required',
                'gender' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            DB::beginTransaction();

            $user->email = $request->email;
            $user->mobile = $request->mobile;
            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;
            $user->alias = $request->alias ?? '';
            $user->co_name = $request->co_name ?? '';
            $user->dob = $request->dob;
            $user->gender = $request->gender;
            $user->phone = $request->phone;
            $user->save();

            $employer->email = $request->email;
            $employer->b2b_company_name = $request->b2b_company_name ?? '';
            $employer->b2b_gst_no = $request->b2b_gst_no ?? '';
            $employer->b2b_pan_no = $request->b2b_pan_no ?? '';
            $employer->b2b_website = $request->b2b_website ?? '';
            $employer->save();

            if($request->hasFile('photo')) {
                $image          = $request->file('photo');
                $filename       = $image->getClientOriginalName();
                $tempid         = rand(10000,99999);

                $s3 = AWS::createClient('s3');
                $fileData = $s3->putObject(array(
                    'Bucket'        => 'cdn.gettruehelp.com',
                    'Key'           => 'img/'.md5($tempid).$filename,
                    'SourceFile'    => $request->file('photo'),
                    'StorageClass'  => 'STANDARD',
                    'ContentType'   => $request->file('photo')->getMimeType(),
                    'ACL'           => 'public-read',
                ));

                if($fileData){
                    if(isset($userpics) && !empty($userpics->id)){
                        $userpics->photo_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                        $userpics->save();
                    } else {
                        $userpics = new UserPic;
                        $userpics->employer_id = $employer->id;
                        $userpics->photo_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                        $userpics->is_verified = 'N';
                        $userpics->save();
                    }                    
                }
            }

            $data['user'] = $user;
            $data['employer'] = $employer;
            $data['userpics'] = $userpics;

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $data,
                    'message'   => 'Profile Updated successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function employer_data(Request $request){
        
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'api_key' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $valid_api = ApiKey::where(['api_key' => $request->api_key, 'status' => 'A'])->first();

            if(isset($valid_api) && !empty($valid_api->id)){

                $employer = DB::table('b2b_users')
                    ->leftJoin('users', 'b2b_users.user_id', '=', 'users.id')
                    ->leftJoin('employees', 'users.id', '=', 'employees.user_id')
                    ->leftJoin('employer_employee_network', 'employees.id', '=', 'employer_employee_network.its_employee')
                    ->leftJoin('employers', 'employer_employee_network.employer_id', '=', 'employers.id')
                    ->select([
                        'users.id as user_id',
                        'users.first_name',
                        'users.middle_name',
                        'users.last_name',
                        'employers.source_type as type',
                        'employers.id as employer_id',
                        'employers.b2b_company_name'
                    ])
                    ->where('users.mobile', $this->trim_mobile($request->mobile))
                    ->first();

                // if(isset($user) && $user->id != ''){
                    
                // }

                // print_r($user);
                // exit;

                // $user = User::select([
                //     'users.id as user_id',
                //     'users.first_name',
                //     'users.middle_name',
                //     'users.last_name',
                //     'employers.source_type as type',
                //     'employers.id as employer_id',
                //     'employers.b2b_company_name'
                //     ])
                // ->leftJoin('employers','users.id','=','employers.user_id')
                // ->leftJoin('user_prefs','users.id','=','user_prefs.user_id')
                // ->where('users.mobile', $this->trim_mobile($request->mobile))
                // ->first();

                if(isset($employer) && !empty($employer->employer_id)){

                    Log::info(json_encode([
                        'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 200 Success.',
                    ]));

                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => $employer,
                            'message'   => 'success',
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }

                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 200 No data found for number '.$request->mobile,
                ]));

                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'No data found for number '.$request->mobile,
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {
                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 403 Unauthorized access.',
                ]));
                $response = response()->json([
                    'response' => [
                        'status'    => 403,
                        'data'      => '',
                        'message'   => 'Unauthorized access.',
                    ]
                ], 403);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    private function trim_mobile($mobile){
        
        $mobile = str_replace("+","", $mobile);
        
        $length = strlen($mobile);
        
        if($length == 11){
            $mobile = substr($mobile, 1);
        } elseif($length == 12) {
            $mobile = substr($mobile, 2);                
        } elseif($length == 13) {
            $mobile = substr($mobile, 3);                
        }

        return $mobile;
    }

    public function employer_profile(){
        
        try {

            $user = Auth::user();
            $allResponse = '';

            if(isset($user) && !empty($user->id)){
                
                $employer = Employer::select('id')->where('user_id', $user->id)->first();
                $userpics = UserPic::where('employer_id', $employer->id)->first();

                $data['first_name'] = $user->first_name;
                $data['middle_name'] = $user->middle_name;
                $data['last_name'] = $user->last_name;
                $data['mobile'] = $user->mobile;
                $data['gender'] = $user->gender;
                $data['dob'] = $user->dob;
                $data['email'] = $employer->email ? $employer->email : $user->email;
                $data['photo'] = $userpics->photo_url ?? '';
                $data['employees'] = '24';
                $data['total_reports'] = '10';
                $data['redcase_reports'] = '5';
                $data['greencase_reports'] = '5';

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $data,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- employer-profile <V1> <DEVICE_ID> <200> Profile Successfully get.',
            ]));

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'failed',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function employer_employee_network()
    {
        try {

            $user = Auth::user();
            $allResponse = '';

            if(isset($user) && !empty($user->id)){
                
                $employer = Employer::select('id')->where('user_id', $user->id)->first();

                $networks = EmployerEmployeeNetwork::where([
                    'employer_employee_network.employer_id' => $employer->id,
                    'employer_employee_network.status' => 'A'
                    ])
                    ->leftJoin('employees', 'employer_employee_network.its_employee', '=', 'employees.id')
                    ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                    ->leftJoin('user_pics', 'employees.id', '=', 'user_pics.employee_id')
                    ->leftJoin('employee_employment_history', 'employees.id', '=', 'employee_employment_history.employee_id')
                    ->leftJoin('employee_types', 'employees.employee_type_id', '=', 'employee_types.id')
                    ->select('users.id as user_id', 'employees.id as employee_id', 'employees.status as verified', 'users.first_name', 'users.middle_name', 'users.last_name', 'users.dob', 'user_pics.photo_url', 'employee_types.type', 'employee_employment_history.employment_start', 'employee_employment_history.employment_stop', 'employee_employment_history.verification_date')
                    ->get();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $networks,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- employer-profile <V1> <DEVICE_ID> <200> Profile Successfully get.',
            ]));

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'failed',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    function post_support(Request $request){
        try {

            $allResponse = '';

            if(isset($request->messege) && !empty($request->messege)){

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $request->all(),
                        'message'   => 'Successfully Posted Support Request.',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function get_account_for_b2b(){
        
        try {

            $allResponse = '';
            $employee = Employee::where('user_id', Auth::id())->first();
            $empInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employee->id)->first();
            $employer = Employer::find($empInfo->employed_by);
            $prefs = UserPref::where('employer_id', $employer->id)->first();

            if(isset($employer->id)){
                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => [
                            'employer' => $employer,
                            'prefs' => $prefs,
                        ],
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
            
                return $response;
            }

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'No Data found',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
        
            return $response;
            

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function add_employee_as_employer(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'employee_id' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $employee = Employee::find($request->employee_id);

            DB::beginTransaction();

            $employer = new Employer;
            $employer->employer_custom_id = rand(1000, 9999);
            $employer->source_type = 'B2C';
            $employer->user_id = $employee->user_id;
            $employer->email = $employee->email ?? '';
            $employer->save();

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Profile Updated successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function details(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'api_key' => 'required',
                'eid' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $valid_api = ApiKey::where(['api_key' => $request->api_key, 'status' => 'A'])->first();

            if(isset($valid_api) && !empty($valid_api->id)){

            if(strlen($request->eid) > 10){
                $employers = Employer::whereRaw('md5(id) = "' . $request->eid . '"')
                    ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                    ->first();
            } else {
                $employers = Employer::where('id', $request->eid)
                    ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                    ->first();
            }

            $response = response()->json([
                'response' => [
                    'status' => 200,
                    'data' => $employers,
                    'message' => 'successful'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
            
            return $response;
        } else {
            $response = response()->json([
                'response' => [
                    'status'    => 403,
                    'data'      => '',
                    'message'   => 'Unauthorized access.',
                ]
            ], 403);

            \LogActivity::addToLog($allResponse, $response);
            
            return $response;
        }

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}
