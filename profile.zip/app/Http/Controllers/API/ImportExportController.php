<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Imports\BulkImport;
use Maatwebsite\Excel\Facades\Excel;
use DB;
use App\DataSource;
use App\User;
use Auth;
use App\Employer;
use App\EmployeeType;
use App\Employee;
use App\EmployerEmployeeNetwork;
use App\EmployeeEmploymentHistory;
use App\UserPref;

class ImportExportController extends Controller
{
    public function import(Request $request) 
    {
    	$data = Excel::toArray(new BulkImport, $request->file('file'));

        try {
          
            $allResponse = json_encode($data);
            $user = Auth::user();                
            $employer = Employer::select('id')->where('user_id', $user->id)->first();

            DB::beginTransaction();

            foreach ($data[0] as $key => $value) {

            	if($key != 0 && !empty($value[1])){

            		$user = User::where([
		                'mobile' => $this->trim_mobile($value[5])
		            ])->first();

		            if(isset($user) && !empty($user->id)){
		                $response = response()->json([
		                    'response' => [
		                        'status' => 401,
		                        'data' => $user,
		                        'message' => 'Already Registered.'
		                    ]
		                ], 400);

		                \LogActivity::addToLog($allResponse, $response);
		                
		                return $response;
		            }

		            if(!empty($request->email)){
		                $userEmail = User::where([
		                    'email' => $value[6]
		                ])->first();

		                if(isset($userEmail) && !empty($userEmail->id)){
		                    $response = response()->json([
		                        'response' => [
		                            'status' => 401,
		                            'data' => $userEmail,
		                            'message' => 'Already Registered.'
		                        ]
		                    ], 400);

		                    \LogActivity::addToLog($allResponse, $response);
		                
		                    return $response;
		                }
		            }

		            $datasource = new DataSource;
		            $datasource->source_name = 'B2B';
		            $datasource->campaign_name = $request->campaign_name ?? '';
		            $datasource->ip_address = $request->ip();
		            $datasource->save();    

		            $parent_datasource = new DataSource;
		            $parent_datasource->source_name = 'B2B';
		            $parent_datasource->campaign_name = $request->campaign_name ?? '';
		            $parent_datasource->ip_address = $request->ip();
		            $parent_datasource->save();

		            $parent = new User;
		            $parent->email = $value[14] ?? '';
		            $parent->mobile = $this->trim_mobile($value[15]);
		            $parent->first_name = $value[9];
		            $parent->middle_name = $value[10] ?? '';
		            $parent->last_name = $value[11];
		            $parent->dob = date('Y-m-d', strtotime($value[12])) ?? '';
		            $parent->gender = $value[13] ?? '';
		            $parent->co_relation = $value[16];
		            $parent->data_source_id = $parent_datasource->id;
		            $parent->save();        

		            $user = new User;
		            $user->mobile = $this->trim_mobile($value[5]);
		            $user->first_name = $value[1];
		            $user->middle_name = $value[2] ?? '';
		            $user->last_name = $value[3];
		            $user->co_name = $parent->id ?? '';
		            $user->dob = date('Y-m-d', strtotime($value[7]));
		            $user->gender = $value[8];
		            $user->co_name = $parent->id;
		            $user->data_source_id = $datasource->id;
		            $user->save();

		            $empType = EmployeeType::where(['type' => $value[17], 'source' => 'B2B'])->select('id')->first();

		            $employee = new Employee;
		            $employee->employee_custom_id = rand(1000,9999);
		            $employee->employee_type_id = $empType->id ?? '';
		            $employee->employee_code = $value[4] ?? '';
		            $employee->user_id = $user->id;
		            $employee->email = $value[6] ?? '';
		            $employee->doj = date('Y-m-d');
		            $employee->save();

		            $network = new EmployerEmployeeNetwork;
		            $network->employer_id = $employer->id;
		            $network->its_employee = $employee->id;
		            $network->status = 'A';
		            $network->save();

		            $history = new EmployeeEmploymentHistory;
		            $history->employee_id = $employee->id;
		            $history->employment_start = date('Y-m-d');
		            $history->employed_by = $employer->id;
		            $history->save();

		            $userpref = new UserPref;
		            $userpref->employee_id = $employee->id;
		            $userpref->lang = $request->language == 'hi' ? 2 : 1;
		            $userpref->save();

		            $user->employee_id = $employee->id;
	            }
	        }

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Registered successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    private function trim_mobile($mobile){
        
        $mobile = str_replace("+","", $mobile);
        
        $length = strlen($mobile);
        
        if($length == 11){
            $mobile = substr($mobile, 1);
        } elseif($length == 12) {
            $mobile = substr($mobile, 2);                
        } elseif($length == 13) {
            $mobile = substr($mobile, 3);                
        }

        return $mobile;
    }
}
