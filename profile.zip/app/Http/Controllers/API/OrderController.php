<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Auth;
use Carbon\Carbon;
use App\Employee;
use App\Employer;
use App\UploadedDocument;
use App\VerificationType;
use App\UserNotification;
use App\Address;
use App\TaskTypeSeverity;
use App\Survey;
use App\SurveyAnswer;
use App\EmployeeEmploymentHistory;
use App\Visitor;
use App\Order;
use App\OrderHistory;
use App\OrderTask;
use App\OrderType;
use App\TaskType;
use App\TaskHistory;
use App\UserDoc;
use App\TaskHistoryDoc;
use App\UserAddress;
use App\ApiKey;

use DateTime;
use DatePeriod;
use DateInterval;
use DB;
use AWS;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use Aws\Exception\AwsException;
use PDF;
use OCR;
use OneSignal;

class OrderController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());
            
            $order_id    = rand(1000000,9999999);
            $totalAmount = array();

            $verifications = explode(',', $request->verifications);

            if($verifications){
                foreach ($verifications as $key => $verification) {
                    $verification = VerificationType::where('id', $verification)->select('id', 'name', 'tat')->first();
                    $maxTat[] = $verification->tat;
                    $order_ids[] = $verification->id;
                    $order_name[] = $verification->name;
                }
            }
            
            $employers = Employer::where('user_id', Auth::id())->first();
            $employees = Employee::find($request->employee_id);

            $max_tat = max($maxTat);

            $date = date('Y-m-d');
            $received_date = date('Y-m-d');
            $actual_tat = $this->getFutureBusinessDay($max_tat, $received_date, $holiday_dates_ymd = []);

            DB::beginTransaction();

            $orders = new Order;
            $orders->order_number = $employers->employer_custom_id.'-'.$employees->employee_custom_id;
            $orders->order_display_ids = implode(',', $order_ids);
            $orders->order_dispaly_desc = implode(',', $order_name);
            $orders->status = 'CREATED';
            $orders->priority = 'NORMAL';
            $orders->tat = $actual_tat;
            $orders->employer_id = $employers->id;
            $orders->employee_id = $request->employee_id;
            $orders->received_date = $received_date;
            $orders->save();

            $orderhistory = new OrderHistory;
            $orderhistory->action = 'CREATED';
            $orderhistory->order_id = $orders->id;
            $orderhistory->order_status = 'CREATED';
            $orderhistory->action_by = Auth::id();
            $orderhistory->save();

            if($verifications){
                foreach ($verifications as $key => $verificId) {

                    $verifications = VerificationType::where('id', $verificId)->first();

                    if(isset($verifications)){
                        $task_deps = explode('|', $verifications->task_deps);

                        if(count($task_deps) > 0){
                            foreach ($task_deps as $key => $task_dep) {

                                $task_num = OrderTask::select('id')->orderBy('id', 'desc')->first();

                                if($task_num->id <= 9){
                                    $task_number = '000'.($task_num->id + 1);
                                } elseif($task_num->id <= 99) {
                                    $task_number = '00'.($task_num->id + 1);
                                } elseif($task_num->id <= 999) {
                                    $task_number = '0'.($task_num->id + 1);
                                } else {
                                    $task_number = $task_num->id + 1;
                                }

                                $task_type = DB::table('task_types')->where('task_type', $task_dep)->first();

                                $ordertasks = new OrderTask;
                                $ordertasks->task_number = $orders->order_number.'-'.$task_number.'-'.date('my');
                                $ordertasks->task_display_id = $task_type->task_type;
                                $ordertasks->order_id = $orders->id;
                                $ordertasks->task_type = $task_type->id;
                                $ordertasks->employer_id = $employers->id;
                                $ordertasks->employee_id = $request->employee_id;
                                $ordertasks->priority = 'NORMAL';
                                $ordertasks->tat = $this->getFutureBusinessDay($task_type->tat, $received_date, $holiday_dates_ymd = []);
                                $ordertasks->status = 'CREATED';
                                $ordertasks->received_date = $received_date;
                                $ordertasks->save();
                            }
                        }
                    }

                    $taskhistory = new TaskHistory;
                    $taskhistory->action = 'CREATED';
                    $taskhistory->task_id = $ordertasks->id;
                    $taskhistory->task_status = 'CREATED';
                    $taskhistory->action_by = Auth::id();
                    $taskhistory->candidate_data = '';
                    $taskhistory->antecedants_data = '';
                    $taskhistory->save();
                }
            }        

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Order placed successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function getFutureBusinessDay($num_business_days, $today_ymd = null, $holiday_dates_ymd = []) {
        $num_business_days = min($num_business_days, 1000);
        $business_day_count = 0;
        $current_timestamp = empty($today_ymd) ? time() : strtotime($today_ymd);
        while ($business_day_count < $num_business_days) {
            $next1WD = strtotime('+1 weekday', $current_timestamp);
            $next1WDDate = date('Y-m-d', $next1WD);        
            if (!in_array($next1WDDate, $holiday_dates_ymd)) {
                $business_day_count++;
            }
            $current_timestamp = $next1WD;
        }
        return date('Y-m-d', $current_timestamp);
    }

    public function get_user_details(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'task_id' => 'required',
                'api_key' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $tasks = OrderTask::whereRaw('md5(id) = "' . $request->task_id . '"')->first();
                $orders = Order::find($tasks->order_id);   
                
                $employers = Employer::where('employers.id', $orders->employer_id)
                    ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                    ->leftJoin('user_pics', 'employers.id', '=', 'user_pics.employer_id')
                    ->select('users.first_name','users.middle_name','users.last_name','employers.employer_custom_id','employers.b2b_company_name','employers.b2b_brand_name','employers.id as employer_id','user_pics.photo_url')
                    ->first();

                $employees = Employee::where('employees.id', $orders->employee_id)
                    ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                    ->leftJoin('user_pics', 'employees.id', '=', 'user_pics.employee_id')
                    ->select('users.first_name','users.middle_name','users.last_name','users.mobile','users.co_name','users.dob','users.gender','employees.employee_custom_id','employees.employee_code','employees.id as employee_id','user_pics.photo_url')
                    ->first();

                $addresses = UserAddress::where(['employee_id' => $orders->employee_id])->first();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => [
                            'tasks' => $tasks,
                            'orders' => $orders,
                            'employers' => $employers,
                            'employees' => $employees,
                            'addresses' => $addresses,
                        ],
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function IsBase64($data) {
        $decoded_data = base64_decode($data, true);
        $encoded_data = base64_encode($decoded_data);
        if ($encoded_data != $data) return false;
        else if (!ctype_print($decoded_data)) return false;

        return true;
    }

    public function does_url_exists($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($code == 200) {
            $status = true;
        } else {
            $status = false;
        }
        curl_close($ch);
        return $status;
    }

    public function post_av_digital(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'task_id' => 'required',
                'api_key' => 'required',
                'address' => 'required',
                'accommodation_status' => 'required',
                'duration_of_stay' => 'required',
                'verified_by' => 'required',
                'relationship_with_candidate' => 'required',
                'contact_no_of_verifier' => 'required',
                'house_picture' => 'required',
                'latitude' => 'required',
                'longitude' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $tasks = OrderTask::whereRaw('md5(id) = "' . $request->task_id . '"')->first();
                $employees = Employee::find($tasks->employee_id);

                $lasthistories = TaskHistory::where('task_id', $tasks->id)->orderBy('id', 'desc')->first(); 
                
                $order = Order::find($tasks->order_id);
                $order->status = 'IN_PROGRESS';
                $order->save();

                $taskhistory = new TaskHistory;
                $taskhistory->action = 'UPDATED';
                $taskhistory->task_id = $tasks->id;
                $taskhistory->task_status = 'IN_PROGRESS';
                $taskhistory->action_by = $employees->user_id;
                $taskhistory->candidate_data = json_encode([
                                                    'address' => $request->address ?? '',
                                                    'accommodation_status' => $request->accommodation_status ?? '',
                                                    'duration_of_stay' => $request->duration_of_stay ?? '',
                                                    'verified_by' => $request->verified_by ?? '',
                                                    'relationship_with_candidate' => $request->relationship_with_candidate ?? '',
                                                    'contact_no_of_verifier' => $request->contact_no_of_verifier ?? '',
                                                    'house_picture' => $request->house_picture ?? '',
                                                    'latitude' => $request->latitude ?? '',
                                                    'longitude' => $request->longitude ?? '',
                                                ]);
                $taskhistory->verification_date = date('Y-m-d');
                $taskhistory->save();


                if($this->IsBase64($request->house_picture) != true){
                    if($this->does_url_exists($request->house_picture) == true){
                        $imageData = 'data: png;base64,'.base64_encode(file_get_contents($request->house_picture));
                    } else {
                        $response = response()->json([
                            'response' => [
                                'status' => 401,
                                'data' => '',
                                'message' => 'Please Pass Valid house picture url.'
                            ]
                        ], 400);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }
                } else {
                    if($this->IsBase64($request->house_picture) == true){
                        $imageData = $request->house_picture;
                    } else {
                        
                        $response = response()->json([
                            'response' => [
                                'status' => 401,
                                'data' => '',
                                'message' => 'Please Pass Valid house picture.'
                            ]
                        ], 400);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }
                }

                if(!empty($imageData)){
                    $image_parts = explode(";base64,", $imageData);
                    $image_base64 = base64_decode($image_parts[1]);
                    $file = storage_path('documents/'.uniqid().'.png');

                    if(file_put_contents($file, $image_base64)) {
                        $s3 = AWS::createClient('s3');
                        $fileData = $s3->putObject(array(
                            'Bucket'        => 'cdn.gettruehelp.com',
                            'Key'           => 'documents/'.md5(rand(1000000000,999999999999)).'.png',
                            'SourceFile'    => $file,
                            'StorageClass'  => 'STANDARD',
                            'ContentType'   => 'image/png',
                            'ACL'           => 'public-read',
                        ));

                        if(!empty($fileData)){
                            $taskhistorydoc = new TaskHistoryDoc;
                            $taskhistorydoc->task_history_id = $taskhistory->id;
                            $taskhistorydoc->document_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                            $taskhistorydoc->document_name = 'House Picture';
                            $taskhistorydoc->save();
                        }
                    }
                }

                if($this->IsBase64($request->address_proof_front) != true){
                    if($this->does_url_exists($request->address_proof_front) == true){
                        $APimageData = 'data: png;base64,'.base64_encode(file_get_contents($request->address_proof_front));
                    } else {
                        
                        $response = response()->json([
                            'response' => [
                                'status' => 401,
                                'data' => '',
                                'message' => 'Please Pass Valid house picture url.'
                            ]
                        ], 400);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }
                } else {
                    if($this->IsBase64($request->address_proof_front) == true){
                        $APimageData = $request->address_proof_front;
                    } else {
                        
                        $response = response()->json([
                            'response' => [
                                'status' => 401,
                                'data' => '',
                                'message' => 'Please Pass Valid house picture.'
                            ]
                        ], 400);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }
                }

                if(!empty($APimageData)){
                    $APimage_parts = explode(";base64,", $APimageData);
                    $APimage_base64 = base64_decode($APimage_parts[1]);
                    $file = storage_path('documents/'.uniqid().'.png');

                    if(file_put_contents($file, $APimage_base64)) {
                        $s3 = AWS::createClient('s3');
                        $fileData = $s3->putObject(array(
                            'Bucket'        => 'cdn.gettruehelp.com',
                            'Key'           => 'documents/'.md5(rand(1000000000,999999999999)).'.png',
                            'SourceFile'    => $file,
                            'StorageClass'  => 'STANDARD',
                            'ContentType'   => 'image/png',
                            'ACL'           => 'public-read',
                        ));

                        if(!empty($fileData)){
                            $taskhistorydoc = new TaskHistoryDoc;
                            $taskhistorydoc->task_history_id = $taskhistory->id;
                            $taskhistorydoc->document_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                            $taskhistorydoc->document_name = 'Address Proof Front';
                            $taskhistorydoc->save();
                        }
                    }
                }

                if(!empty($request->address_proof_back) && $this->IsBase64($request->address_proof_back) != true){
                    if($this->does_url_exists($request->address_proof_back) == true){
                        $APBimageData = 'data: png;base64,'.base64_encode(file_get_contents($request->address_proof_back));
                    } else {
                        
                        $response = response()->json([
                            'response' => [
                                'status' => 401,
                                'data' => '',
                                'message' => 'Please Pass Valid house picture url.'
                            ]
                        ], 400);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }
                } else {
                    if(!empty($request->address_proof_back) && $this->IsBase64($request->address_proof_back) == true){
                        $APBimageData = $request->address_proof_back;
                    } else {
                        
                        $response = response()->json([
                            'response' => [
                                'status' => 401,
                                'data' => '',
                                'message' => 'Please Pass Valid house picture.'
                            ]
                        ], 400);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }
                }

                if(!empty($APBimageData)){
                    $APBimage_parts = explode(";base64,", $APBimageData);
                    $APBimage_base64 = base64_decode($APBimage_parts[1]);
                    $file = storage_path('documents/'.uniqid().'.png');

                    if(file_put_contents($file, $APBimage_base64)) {
                        $s3 = AWS::createClient('s3');
                        $fileData = $s3->putObject(array(
                            'Bucket'        => 'cdn.gettruehelp.com',
                            'Key'           => 'documents/'.md5(rand(1000000000,999999999999)).'.png',
                            'SourceFile'    => $file,
                            'StorageClass'  => 'STANDARD',
                            'ContentType'   => 'image/png',
                            'ACL'           => 'public-read',
                        ));

                        if(!empty($fileData)){
                            $taskhistorydoc = new TaskHistoryDoc;
                            $taskhistorydoc->task_history_id = $taskhistory->id;
                            $taskhistorydoc->document_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                            $taskhistorydoc->document_name = 'Address Proof Front';
                            $taskhistorydoc->save();
                        }
                    }
                }

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $request->all(),
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
                
            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {
            
            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function post_self_health_check(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'task_id' => 'required',
                'api_key' => 'required',
                'current_temprature' => 'required',
                'had_symptoms' => 'required',
                'tested_positive' => 'required',
                'proximate_contact' => 'required',
                'confirm_answer' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $allResponse = json_encode($request->all());
            
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $tasks = OrderTask::whereRaw('md5(id) = "' . $request->task_id . '"')->first();
                $employees = Employee::find($tasks->employee_id);

                $lasthistories = TaskHistory::where('task_id', $tasks->id)->orderBy('id', 'desc')->first(); 
                
                $order = Order::find($tasks->order_id);
                $order->status = 'IN_PROGRESS';
                $order->save();

                $taskhistory = new TaskHistory;
                $taskhistory->action = 'UPDATED';
                $taskhistory->task_id = $tasks->id;
                $taskhistory->task_status = 'IN_PROGRESS';
                $taskhistory->action_by = $employees->user_id;
                $taskhistory->candidate_data = json_encode([
                                                    'current_temprature' => $request->current_temprature ?? '',
                                                    'had_symptoms' => $request->had_symptoms ?? '',
                                                    'tested_positive' => $request->tested_positive ?? '',
                                                    'proximate_contact' => $request->proximate_contact ?? '',
                                                    'confirm_answer' => $request->confirm_answer ?? '',
                                                ]);
                $taskhistory->verification_date = date('Y-m-d');
                $taskhistory->save();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $request->all(),
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
                
            } else {          
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {
            
            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function get_survey(Request $request)
    {
        
        $allResponse = json_encode($request->all());
        
        try {

            $empIds = Employee::where('user_id', Auth::id())->select('id')->first();
            $empHistory = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $empIds->id)->orderBy('updated_at', 'desc')->first();

            $employer = Employer::find($empHistory->employed_by);

            $validator = Validator::make($request->all(), [
                'api_key' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $tasks = DB::table('surveys')
                    ->leftJoin('employees', 'surveys.employee_id', '=', 'employees.id')
                    ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                    ->select(DB::raw("'N/A' as person_to_meet"), DB::raw("'N/A' as mobile"),'surveys.*', 'users.first_name', 'users.middle_name', 'users.last_name')
                    ->where('employer_id', $empHistory->employed_by)
                    ->orderBy('surveys.id', 'desc')->get();
                    // ->paginate(15);

                foreach ($tasks as $key => $task) {
                    if(isset($task->visitor_id))
                    {
                        $visitor = Visitor::find($task->visitor_id);
                        $task->first_name=$visitor->first_name;
                        $task->middle_name=$visitor->middle_name;
                        $task->last_name=$visitor->last_name;
                        $task->mobile=$visitor->mobile;
                        $task->person_to_meet=$visitor->person_to_meet;
                    }
                }

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $tasks,
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function get_survey_details(Request $request, $id)
    {       
        $allResponse = json_encode($request->all());

        try {

            $survey = Survey::whereRaw('md5(surveys.id) = "' . $id . '"')
                ->select('surveys.*', 'employers.b2b_company_name', 'employers.b2b_brand_name', 'users.first_name', 'users.middle_name', 'users.last_name', 'users.mobile', 'employee_types.type', 'employees.id as employee_id')
                ->leftJoin('employees', 'surveys.employee_id', '=', 'employees.id')
                ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                ->leftJoin('employers', 'surveys.employer_id', '=', 'employers.id')
                ->leftJoin('employee_types', 'employees.employee_type_id', '=', 'employee_types.id')
                ->first();

            $validator = Validator::make($request->all(), [
                'api_key' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $survey_answers = SurveyAnswer::where('survey_id', $survey->id)
                    ->leftJoin('survey_questions', 'survey_answers.question_id', '=', 'survey_questions.id')
                    ->select('survey_answers.*','survey_questions.text')
                    ->get();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => [
                            'survey' => $survey,
                            'survey_answers' => $survey_answers,
                        ],
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}