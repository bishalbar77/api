<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use AWS;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use Aws\Exception\AwsException;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use App\EmployeeEmploymentHistory;
use App\EmployerEmployeeNetwork;
use App\EmployeeLookupHistory;
use App\ApiActiveSessions;
use App\DocumentType;
use App\EmployeeType;
use App\EmployeeReview;
use App\VerificationType;
use App\UserWebProfile;
use App\UserAddress;
use App\DataSource;
use App\Employee;
use App\Employer;
use App\UserPref;
use App\UserPic;
use App\UserDoc;
use App\Survey;
use DateTime;
use App\User;
use App\Uid;
use Geocoder;
use DB;
use Log;

class StudentController extends Controller
{
    /**
     * Create a new user instance after a valid registration.
     *
     * @param array $data
     * @return
     */

    function store(Request $request)
    {
        try {
            
            $allResponse = json_encode($request->all());
            
            $user = Auth::user();
            
            $employees = Employee::where('user_id', Auth::id())->first();

            $employerInfo = DB::table('employer_employee_network')
                ->select('employer_id')
                ->where('its_employee', $employees->id)
                ->orderBy('id', 'DESC')
                ->first();

            $employer = Employer::find($employerInfo->employer_id);

            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'country_code' => 'required',
                'mobile' => 'required',
                'dob' => 'required',
                'gender' => 'required',
                'employee_types_id' => 'required',          
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $dob = new DateTime(date('Y-m-d', strtotime($request->dob)));
            $today   = new DateTime('today');

            if($dob->diff($today)->y < 18){
                $validator = Validator::make($request->all(), [
                    'first_name' => 'required',
                    'last_name' => 'required',
                    'mobile' => 'required',
                    'dob' => 'required',
                    'gender' => 'required',   
                    'parent_mobile' => 'required',
                    'parent_first_name' => 'required',
                    'parent_last_name' => 'required',
                    'parent_last_name' => 'required',
                    'employee_types_id' => 'required',
                ]);

                if($validator->fails()){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'message' => 'Validation failed',
                            'errors' => $validator->errors()
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }
            }

            $user = User::where([
                'mobile' => $this->trim_mobile($request->mobile)
            ])->first();

            if(isset($user) && !empty($user->id)){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => $user,
                        'message' => 'Already Registered.'
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            if(!empty($request->email)){
                $userEmail = User::where([
                    'email' => $request->email
                ])->first();

                if(isset($userEmail) && !empty($userEmail->id)){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => $userEmail,
                            'message' => 'Already Registered.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            }

            DB::beginTransaction();      

            $datasource = new DataSource;
            $datasource->source_name = 'B2B';
            $datasource->campaign_name = $request->campaign_name ?? '';
            $datasource->ip_address = $request->ip();
            $datasource->save();

            if(!empty($request->parent_first_name)){

                $parent_datasource = new DataSource;
                $parent_datasource->source_name = 'B2B';
                $parent_datasource->campaign_name = $request->campaign_name ?? '';
                $parent_datasource->ip_address = $request->ip();
                $parent_datasource->save();

                $parent = new User;
                $parent->email = $request->parent_email ?? '';
                $parent->country_code = $request->country_code;
                $parent->mobile = $this->trim_mobile($request->parent_mobile);
                $parent->first_name = $request->parent_first_name;
                $parent->middle_name = $request->parent_middle_name ?? '';
                $parent->last_name = $request->parent_last_name;
                $parent->dob = date('Y-m-d', strtotime($request->dob)) ?? '';
                $parent->gender = $request->gender ?? '';
                $parent->co_relation = $request->co_relation;
                $parent->data_source_id = $parent_datasource->id;
                $parent->save();        
            }

            $user = new User;
            $user->country_code = $request->country_code;
            $user->mobile = $this->trim_mobile($request->mobile);
            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;
            $user->co_name = $parent->id ?? '';
            $user->dob = date('Y-m-d', strtotime($request->dob));
            $user->gender = $request->gender;
            $user->data_source_id = $datasource->id;
            $user->save();

            $employee = new Employee;
            $employee->employee_custom_id = rand(1000,9999);
            $employee->employee_type_id = $request->employee_types_id;
            $employee->employee_code = $request->student_code;
            $employee->user_id = $user->id;
            $employee->email = $request->email ?? '';
            $employee->doj = $request->doj ? date('Y-m-d', strtotime($request->doj)) : date('Y-m-d');
            $employee->save();

            $network = new EmployerEmployeeNetwork;
            $network->employer_id = $employer->id;
            $network->its_employee = $employee->id;
            $network->status = 'A';
            $network->save();

            $lookup = new EmployeeLookupHistory;
            $lookup->employee_id = $employee->id;
            $lookup->latitude = $request->latitude;
            $lookup->longitude = $request->longitude;
            $lookup->ip_address = $request->ip();
            $lookup->browser_info = $request->header('User-Agent');
            $lookup->lookup_by = Auth::id();
            $lookup->save();

            $history = new EmployeeEmploymentHistory;
            $history->employee_id = $employee->id;
            $history->employment_start = date('Y-m-d');
            $history->employed_by = $employer->id;
            $history->save();

            $userpref = new UserPref;
            $userpref->employee_id = $employee->id;
            $userpref->lang = $request->language == 'hi' ? 2 : 1;
            $userpref->save();

            $user->employee_id = $employee->id;

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $user,
                    'message'   => 'Registered successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function upload_employee_photo(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());
            $user = Auth::user(); 

            $validator = Validator::make($request->all(), [             
                'employee_id' => 'required',               
                'photo' => 'required',
                'source' => 'in:B2B,B2C,BOT'          
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            DB::beginTransaction();   

            if($request->source == 'BOT'){
                $imageData = 'data: png;base64,'.base64_encode(file_get_contents($request->photo));
            } else {
                $imageData = $request->photo;
            }
            
            $image_parts = explode(";base64,", $imageData);

            $image_base64 = base64_decode($image_parts[1]);
            
            $file = storage_path('profile/'.uniqid().'.png');

            if(file_put_contents($file, $image_base64)) {
                $s3 = AWS::createClient('s3');
                $fileData = $s3->putObject(array(
                    'Bucket'        => 'cdn.gettruehelp.com',
                    'Key'           => 'img/'.md5(rand(1000000000,999999999999)).'.png',
                    'SourceFile'    => $file,
                    'StorageClass'  => 'STANDARD',
                    'ContentType'   => 'image/png',
                    'ACL'           => 'public-read',
                ));

                if($fileData){
                    $userpic = new UserPic;
                    $userpic->employee_id = $request->employee_id;
                    $userpic->photo_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                    $userpic->uploaded_by = $user->id;
                    $userpic->save();
                }
            }

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $request->employee_id,
                    'message'   => 'Uploaded successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    private function trim_mobile($mobile){
        
        $mobile = str_replace("+","", $mobile);
        
        $length = strlen($mobile);
        
        if($length == 11){
            $mobile = substr($mobile, 1);
        } elseif($length == 12) {
            $mobile = substr($mobile, 2);                
        } elseif($length == 13) {
            $mobile = substr($mobile, 3);                
        }

        return $mobile;
    }

    public function otp($phone, $otp)
    {
        try{

            $SnSclient          = new SnsClient([
                'region'        => 'us-east-1',
                'version'       => '2010-03-31',
                'credentials'   => [
                'key'           => 'AKIA4SH5KM3GHHQL5CUF',
                'secret'        => 'tqp57AghAQCK13orjlYugUHrQ/BecwQrgod/AVfx',
                ]
            ]);

            $result = $SnSclient->publish([
                'Message'     => $otp.' is your TrueHelp OTP code. DO NOT share the OTP with ANYONE.',
                'PhoneNumber' => $phone,
            ]);

            return response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'OTP Sent to Registered Number.',
                ]
            ], 200);
            
        } catch (\Exception $e) {
            return response()->json([
                'response' => [
                    'status'    => '500',
                    'data'      => "",
                    'message'   => $e->getMessage()
                ]
            ], 500);
        }
    }

    public function employee_profile($employee_id)
    {
        try{
            $allResponse = '';
            $employee = Employee::select('users.id as user_id', 'users.first_name', 'users.middle_name', 'users.last_name', 'users.mobile', 'users.dob', 'users.gender', 'employee_types.type', 'employee_employment_history.salary', 'employee_employment_history.employment_start')
                ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                ->leftJoin('employee_types', 'employees.employee_type_id', '=', 'employee_types.id')
                ->leftJoin('employee_employment_history', 'employees.id', '=', 'employee_employment_history.employee_id')
                ->where('employees.id', $employee_id)
                ->first();

            $user = User::find($employee->user_id);
            
            $address = UserAddress::where(['employee_id' => $employee_id, 'status' => 'A'])->get();
            $user_pics = UserPic::select('photo_url', 'is_verified')->where('employee_id', $employee_id)->get();
            $user_docs = UserDoc::select('document_types.name as document_name', 'user_docs.doc_url')
                ->leftJoin('document_types', 'user_docs.doc_type_id', '=', 'document_types.id')
                ->where('user_docs.user_id', $employee->user_id)->get();

            $employment_histories = EmployeeEmploymentHistory::select('users.first_name', 'users.middle_name', 'users.last_name', 'employee_employment_history.salary', 'employee_employment_history.employment_start', 'employee_employment_history.employment_stop', 'employee_employment_history.is_verified')
                ->leftJoin('employers', 'employee_employment_history.employed_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->where('employee_employment_history.employee_id', $employee_id)->get();

            $employee_lookup_histories = EmployeeLookupHistory::select('users.first_name', 'users.middle_name', 'users.last_name', 'employee_lookup_histories.latitude', 'employee_lookup_histories.longitude', 'employee_lookup_histories.created_at', 'employee_types.type as employee_type', 'document_types.name as document_type')
                ->leftJoin('employers', 'employee_lookup_histories.lookup_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->leftJoin('employee_types', 'employee_lookup_histories.employee_type_id', '=', 'employee_types.id')
                ->leftJoin('document_types', 'employee_lookup_histories.doc_type_id', '=', 'document_types.id')
                ->where('employee_lookup_histories.employee_id', $employee_id)->get();

            $employee_reviews = EmployeeReview::select('users.first_name', 'users.middle_name', 'users.last_name', 'employee_reviews.rating', 'employee_reviews.review')
                ->leftJoin('employers', 'employee_reviews.reviewed_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->where(['employee_reviews.employee_id' => $employee_id, 'employee_reviews.status' => 'A'])->get();

            $verification_types = VerificationType::select('name', 'amount', 'icon_url', 'description')
                ->where(['status' => 'A', 'source' => 'B2C'])->get();

            $user_web_profiles = UserWebProfile::select('fb_connection_id', 'li_connection_id', 'twtr_connection_id')
                ->where(['id' => $user->user_web_profile_id])->first();

            $data['employee'] = $employee;
            $data['address'] = $address;
            $data['user_pics'] = $user_pics;
            $data['user_docs'] = $user_docs;
            $data['employment_histories'] = $employment_histories;
            $data['employee_lookup_histories'] = $employee_lookup_histories;
            $data['employee_reviews'] = $employee_reviews;
            $data['verification_types'] = $verification_types;
            $data['user_web_profiles'] = $user_web_profiles;

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $data,
                    'message'   => 'success'
                ]
            ], 200);
            
            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        
        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function IsBase64($data) {
        $decoded_data = base64_decode($data, true);
        $encoded_data = base64_encode($decoded_data);
        if ($encoded_data != $data) return false;
        else if (!ctype_print($decoded_data)) return false;

        return true;
    }

    public function does_url_exists($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($code == 200) {
            $status = true;
        } else {
            $status = false;
        }
        curl_close($ch);
        return $status;
    }
}
