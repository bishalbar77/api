<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\EmployerEmployeeNetwork;
use App\SurveyAnswer;
use App\Employer;
use App\Employee;
use App\Visitor;
use App\ApiKey;
use App\Survey;
use App\User;
use Carbon\Carbon;
use DB;
use AWS;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use Aws\Exception\AwsException;
use App\EmployeeEmploymentHistory;
use App\UserNotification;

class SurveyController extends Controller
{
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            
            $allResponse = json_encode($request->all());

            $employees = Employee::where('employees.id', $request->employee_id)
                ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                ->select('users.first_name','users.middle_name','users.last_name','users.mobile','employees.employee_custom_id','employees.employee_code','employees.id as employee_id')
                ->first();

            $employerInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $request->employee_id)->orderBy('updated_at', 'desc')->first();

            $employers = Employer::where('id', $employerInfo->employed_by)
                ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                ->first();

            DB::beginTransaction();

            $survey = new Survey;
            $survey->survey_type = 'HEALTH_CHECK';
            $survey->employee_id = $request->employee_id;
            $survey->employer_id = $employers->employer_id;
            $survey->save();

            $SnSclient          = new SnsClient([
                'region'        => 'us-east-1',
                'version'       => '2010-03-31',
                'credentials'   => [
                'key'           => 'AKIA4SH5KM3GOZGMNHLP',
                'secret'        => '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',
                ]
            ]);

            $brand = $employers->b2b_brand_name ? ' ('.$employers->b2b_brand_name.')' : '';
            $company = $employers->b2b_company_name.' '.$brand;
            $message = 'Hi '.$employees->first_name.', Health Screening Available from '.$company.'. Please complete the screening before departing for the Day. Have a Nice Day. https://www.gettruehelp.com/healthcheck/?eid='.md5($employees->employee_id);

            $result = $SnSclient->publish([
                'Message'     => $message,
                'PhoneNumber' => '+91'.$employees->mobile,
            ]);

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Order placed successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function deleteSurvey($id)
    {
        try {

            $allResponse = json_encode($id);
            $survey = Survey::find($id);
            $survey->delete();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $survey,
                    'message'   => 'Survey deleted successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function generate_message(Request $request)
    {
        try {
            
            $allResponse = json_encode($request->all());

            $employees = Employee::where('employees.id', $request->employee_id)
                ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                ->select('users.first_name','users.middle_name','users.last_name','users.mobile','employees.employee_custom_id','employees.employee_code','employees.id as employee_id')
                ->first();

            $employerInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $request->employee_id)->orderBy('updated_at', 'desc')->first();

            $employers = Employer::where('id', $employerInfo->employed_by)
                ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                ->first();

            DB::beginTransaction();

            $SnSclient          = new SnsClient([
                'region'        => 'ap-south-1',
                'version'       => '2010-03-31',
                'credentials'   => [
                'key'           => 'AKIA4SH5KM3GOZGMNHLP',
                'secret'        => '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',
                ]
            ]);

            $brand = $employers->b2b_brand_name ? ' ('.$employers->b2b_brand_name.')' : '';
            $company = $employers->b2b_company_name.' '.$brand;
            $message = 'REMINDER: Hi '.$employees->first_name.', Health Screening Available from '.$company.'. Please complete the screening before departing for the Day. Have a Nice Day. https://www.gettruehelp.com/healthcheck/?eid='.md5($employees->employee_id);

            $result = $SnSclient->publish([
                'Message'     => $message,
                'PhoneNumber' => '+91'.$employees->mobile,
            ]);

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $message,
                    'message'   => 'Order has been placed successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function generate_runtime_reminder(Request $request)
    {
        try {
            
            $allResponse = json_encode($request->all());

            $employees = DB::table('employees')
                ->join('users', 'users.id','=', 'employees.user_id')
                ->select('users.first_name','users.middle_name','users.last_name','users.mobile','employees.employee_custom_id','employees.employee_code','employees.id as employee_id')
                ->get();
                
            foreach($employees as $employee)
            {
                $employerInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employee->employee_id)->orderBy('updated_at', 'desc')->first();

                if(isset($employerInfo))
                {
                    // $employers = Employer::where('id', $employerInfo->employed_by)
                    // ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                    // ->first();

                    // DB::beginTransaction();

                    // $SnSclient          = new SnsClient([
                    //     'region'        => 'ap-south-1',
                    //     'version'       => '2010-03-31',
                    //     'credentials'   => [
                    //     'key'           => 'AKIA4SH5KM3GOZGMNHLP',
                    //     'secret'        => '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',
                    //     ]
                    // ]);

                    // $brand = $employers->b2b_brand_name ? ' ('.$employers->b2b_brand_name.')' : '';
                    // $company = $employers->b2b_company_name.' '.$brand;
                    // $message = 'REMINDER: Hi '.$employee->first_name.', Health Screening Available from '.$company.'. Please complete the screening before departing for the Day. Have a Nice Day. https://www.gettruehelp.com/healthcheck/?eid='.md5($employee->employee_id);

                    // $result = $SnSclient->publish([
                    //     'Message'     => $message,
                    //     'PhoneNumber' => '+91'.$employee->mobile,
                    // ]);

                    // DB::commit();
                }
            }
            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $employees,
                    'message'   => 'Order has been placed successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'Failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {

        try {

            $validator = Validator::make($request->all(), [
                'api_key' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
                
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                if(isset($request->employee_id))
                {
                    $employees = Employee::whereRaw('md5(employees.id) = "' . $request->employee_id . '"')
                        ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                        ->select('users.first_name','users.middle_name','users.last_name','employees.employee_custom_id','employees.employee_code','employees.id as employee_id')
                        ->first();

                    $employerInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employees->employee_id)->orderBy('updated_at', 'desc')->first();

                    $employers = Employer::where('id', $employerInfo->employed_by)
                        ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                        ->first();

                    $old_survey = Survey::where('employee_id', $employees->employee_id)->orderBy('id', 'desc')->take(4)->get();

                    $survey = Survey::where('employee_id', $employees->employee_id)->orderBy('id', 'desc')->first();

                    $response = response()->json([
                        'response' => [
                            'status' => 200,
                            'data' => [
                                'employers' => $employers,
                                'employees' => $employees,
                                'old_survey' => $old_survey,
                                'survey' => $survey,
                            ],
                            'message' => 'success'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }
                elseif ($request->visitor_id) 
                {
                    $visitors = Visitor::whereRaw('md5(visitors.id) = "' . $request->visitor_id . '"')
                        ->select('visitors.first_name','visitors.middle_name','visitors.last_name','employer_id','id as employee_id')
                        ->first();

                    $employers = Employer::where('id', $visitors->employer_id)
                        ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                        ->first();

                    $old_survey = '';

                    $survey = Survey::where('visitor_id', $visitors->employee_id)->orderBy('id', 'desc')->first();

                    $response = response()->json([
                        'response' => [
                            'status' => 200,
                            'data' => [
                                'employers' => $employers,
                                'employees' => $visitors,
                                'old_survey' => $old_survey,
                                'survey' => $survey,
                            ],
                            'message' => 'success'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }
                else
                {
                    $response = response()->json([
                        'response' => [
                            'status'    => 400,
                            'data'      => '',
                            'message'   => 'No User ID found'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                    
                    return $response;
                }

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function details(Request $request)
    {

        try {

            $validator = Validator::make($request->all(), [
                'survey_id' => 'required',
                'api_key' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
                
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){
                
                $survey = Survey::whereRaw('md5(id) = "' . $request->survey_id . '"')->first();

                $employees = Employee::where('employees.id', $survey->employee_id)
                    ->leftJoin('users', 'employees.user_id', '=', 'users.id')
                    ->select('users.first_name','users.middle_name','users.last_name','employees.employee_custom_id','employees.employee_code','employees.id as employee_id')
                    ->first();

                $employers = Employer::where('id', $survey->employer_id)
                    ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                    ->first();


                $response = response()->json([
                    'response' => [
                        'status' => 200,
                        'data' => [
                            'employers' => $employers,
                            'employees' => $employees,
                            'survey' => $survey,
                        ],
                        'message' => 'successful'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'question_data' => 'required',
                'survey_id' => 'required',
                'api_key' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $allResponse = json_encode($request->all());

                if(!is_array(json_decode($request->question_data))){
                    $response = response()->json([
                        'response' => [
                            'status'    => 401,
                            'data'      => '',
                            'message'   => 'Please submit valid question Answer data.'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                        
                    return $response;
                }

                $postData = json_decode($request->question_data);

                $score = $this->get_survey_matrix($postData);

                DB::beginTransaction();

                $res = array();
                
                $survey = Survey::where('id', $request->survey_id)->first();
                $survey_id = $survey->id;
                $employer_id = $survey->employer_id;
                $visitor_id = $survey->visitor_id;
                $surveyUserType = ($survey->visitor_id!=null) ? "Visitor" : "Employee";

                SurveyAnswer::where('survey_id', $survey->id)->delete();

                foreach ($postData[0]->question_id as $key => $value) {

                    $ans = $postData[0]->question_answer[$key];

                    if($postData[0]->question_id[$key] == 6)
                    {
                        if($this->does_url_exists($ans) == true)
                        {
                            $imageData = 'data: png;base64,'.base64_encode(file_get_contents($ans));
                        }

                        if(!empty($imageData))
                        {
                            $image_parts = explode(";base64,", $imageData);
                            $image_base64 = base64_decode($image_parts[1]);
                            $file = storage_path('documents/'.uniqid().'.png');

                            if(file_put_contents($file, $image_base64)) 
                            {
                                $s3 = AWS::createClient('s3');
                                $fileData = $s3->putObject(array(
                                    'Bucket'        => 'cdn.gettruehelp.com',
                                    'Key'           => 'documents/'.md5(rand(1000000000,999999999999)).'.png',
                                    'SourceFile'    => $file,
                                    'StorageClass'  => 'STANDARD',
                                    'ContentType'   => 'image/png',
                                    'ACL'           => 'public-read',
                                ));

                                if(!empty($fileData)){
                                   $ans = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                                }
                            }
                        }
                    }

                    if($ans != '')
                    {
                        $surveyanswer = new SurveyAnswer;
                        $surveyanswer->survey_id = $survey_id;
                        $surveyanswer->question_id = $postData[0]->question_id[$key];
                        $surveyanswer->question_answer = $ans;
                        $surveyanswer->save();
                    }
                }

                $employers = Employer::where('id', $employer_id)
                                ->select('employer_custom_id','b2b_company_name','mobile','b2b_brand_name','id as employer_id')
                                ->first();

                $brand = $employers->b2b_brand_name ? ' ('.$employers->b2b_brand_name.')' : '';
                $company = $employers->b2b_company_name.' '.$brand;

                if(array_sum($score) > 9){
                    
                    $conc = 'RED';
                    if($visitor_id!=null)
                    {
                        $nf = Survey::select('visitors.first_name', 'visitors.last_name')
                        ->Join('visitors', 'surveys.visitor_id', '=', 'visitors.id')
                        ->where('surveys.id', $survey_id)
                        ->get();
                    }
                    else
                    {
                        $nf = Survey::select('users.first_name', 'users.last_name')
                        ->Join('employees', 'surveys.employee_id', '=', 'employees.id')
                        ->Join('users','employees.user_id', '=', 'users.id')
                        ->where('surveys.id', $survey_id)
                        ->get();
                    }
                    $message = "Red Case for ".$nf[0]->first_name." is found";

                    DB::beginTransaction();

                    $SnSclient          = new SnsClient([
                        'region'        => 'ap-south-1',
                        'version'       => '2010-03-31',
                        'credentials'   => [
                        'key'           => 'AKIA4SH5KM3GOZGMNHLP',
                        'secret'        => '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',
                        ]
                    ]);

                    $snsMessage = 'Hello '.$company .". ".$nf[0]->first_name.' '. $nf[0]->last_name.'( '.$surveyUserType.' )'." is found to be at high risk. Please login to your healthcheck dashboard to check the report " . 'https://enterprise.gettruehelp.com/surveys/details/'.md5($survey_id);
                    $result = $SnSclient->publish([
                        'Message'     => $snsMessage,
                        'PhoneNumber' => '+91'.$employers->mobile,
                    ]);

                    DB::commit();

                    UserNotification::saveNotification($employer_id,$message,'https://enterprise.gettruehelp.com/surveys/details/'.md5($survey_id));
                
                } elseif(array_sum($score) > 4){
                    
                    $conc = 'YELLOW';
                    if($visitor_id!=null)
                    {
                        $nf = Survey::select('visitors.first_name', 'visitors.last_name')
                        ->Join('visitors', 'surveys.visitor_id', '=', 'visitors.id')
                        ->where('surveys.id', $survey_id)
                        ->get();
                    }
                    else
                    {
                        $nf = Survey::select('users.first_name', 'users.last_name')
                        ->Join('employees', 'surveys.employee_id', '=', 'employees.id')
                        ->Join('users','employees.user_id', '=', 'users.id')
                        ->where('surveys.id', $survey_id)
                        ->get();
                    }
                    $message = "Yellow Case for ".$nf[0]->first_name." is found";

                    DB::beginTransaction();

                    $SnSclient          = new SnsClient([
                        'region'        => 'ap-south-1',
                        'version'       => '2010-03-31',
                        'credentials'   => [
                        'key'           => 'AKIA4SH5KM3GOZGMNHLP',
                        'secret'        => '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',
                        ]
                    ]);

                    $snsMessage = 'Hello '.$company .". ".$nf[0]->first_name.' '. $nf[0]->last_name.'( '.$surveyUserType.' )'." is found to be at medium risk. Please login to your healthcheck dashboard to check the report " . 'https://enterprise.gettruehelp.com/surveys/details/'.md5($survey_id);
                    $result = $SnSclient->publish([
                        'Message'     => $snsMessage,
                        'PhoneNumber' => '+91'.$employers->mobile,
                    ]);

                    DB::commit();

                    UserNotification::saveNotification($employer_id,$message,'https://enterprise.gettruehelp.com/surveys/details/'.md5($survey_id));
                
                } else {
                    $conc = 'GREEN';
                }

                $survey->survey_start = $postData[0]->survey_start ? date('Y-m-d H:i:s', strtotime($postData[0]->survey_start)) : date('Y-m-d H:i:s');
                $survey->survey_end = $postData[0]->survey_start ? date('Y-m-d H:i:s', strtotime($postData[0]->survey_start)) : date('Y-m-d H:i:s');
                $survey->severity = $conc;
                $survey->survey_status = 'COMPLETE';
                $survey->save();

                DB::commit();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => [
                            'ret_url' => 'https://www.gettruehelp.com/healthcheck/?eid='.md5($survey->employee_id)
                        ],
                        'message'   => 'Answer Submitted successfully'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                    
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function get_survey_matrix($postData)
    {
        $score = array();
        foreach ($postData[0]->question_id as $key => $value) {

            $ans = $postData[0]->question_answer[$key];

            if($postData[0]->question_id[$key] == 2){
                if($ans == 'Yes'){
                    $score[] = 10;
                    break;                
                }
                $score[] = 0;
            }
            
            if($postData[0]->question_id[$key] == 7){
                if($ans == 'Yes'){
                    $score[] = 1;             
                }
                $score[] = 0;            
            }

            if($postData[0]->question_id[$key] == 8){
                if($ans == 'Metro_Bus'){
                    $score[] = 1;       
                }
                if($ans == 'Taxi_Auto'){
                    $score[] = 0.5;         
                }
                if($ans == 'Personal'){
                    $score[] = 0;       
                }
                $score[] = 0;            
            }

            if($postData[0]->question_id[$key] == 9){
                if($ans == 'Yes'){
                    $score[] = 1;          
                }
                $score[] = 0;            
            }

            if($postData[0]->question_id[$key] == 11){
                if($ans == 'Less_than_5'){
                    $score[] = 0;          
                }
                if($ans == '5_15'){
                    $score[] = 0.75;       
                }
                if($ans == 'More_than_15'){
                    $score[] = 1.5;        
                }
                $score[] = 0;            
            }

            if($postData[0]->question_id[$key] == 12){
                if($ans == 'Yes'){
                    $score[] = 1.5;          
                }
                $score[] = 0;            
            }

            if($postData[0]->question_id[$key] == 13){
                if($ans == 'Cough'){
                    $score[] = 2.5;          
                }
                if($ans == 'Fever'){
                    $score[] = 2.5;          
                }
                if($ans == 'Difficulty_Breathing'){
                    $score[] = 2.5;          
                }
                if($ans == 'Loss_senses'){
                    $score[] = 2.5;          
                }
                $score[] = 0;            
            }

            if($postData[0]->question_id[$key] == 4){
                if($ans >= 100){
                    $score[] = 2.5;          
                }
                $score[] = 0;            
            }

        }

        return $score;
    }

    public function does_url_exists($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($code == 200) {
            $status = true;
        } else {
            $status = false;
        }
        curl_close($ch);
        return $status;
    }


    public function dashboard(Request $request){

        try {

            $allResponse = '';

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){
                $dateTime = date('M d, Y');//date("Y/m/d");
                $today = date("Y-m-d 00:00:00");
                $d=strtotime("yesterday");
                $yesterday_start = date("Y-m-d 00:00:00", $d);
                $yesterday_end = date("Y-m-d 23:59:59", $d);
                $total_assigned = Survey::select('employee_id')
                    ->where('created_at', '>' , $today)
                    ->count();
                $total_assigned = ($total_assigned > 0)?$total_assigned :1; 
                $response_received = Survey::select('employee_id')
                        ->where('created_at', '>' , $today)
                        ->where('survey_end' , '!=' , NULL)
                        ->count();
                $response_received = $response_received*100/$total_assigned;
                $arrivals_verified = Survey::select('employee_id')
                        ->where('created_at', '>' , $today)
                        ->where('severity' , '=' , 'GREEN')
                        ->count();
                $arrivals_verified = $arrivals_verified*100/$total_assigned;
                $student_denied = Survey::select('employee_id')
                        ->where('created_at', '>' , $today)
                        ->where('severity' , '=' , 'RED')
                        ->count();
                $response_needed = Survey::select('employee_id')
                        ->where('created_at', '>' , $today)
                        ->where('survey_start' , '=' , NULL)
                        ->count();
                $student_reported_symtomps = Survey::select('employee_id')
                        ->where('created_at', '>' , $today)
                        ->where('survey_start' , '=' , NULL)
                        ->count();
                $new_covid_reports = SurveyAnswer::select('id')
                        ->where('created_at', '>' , $today)
                        ->where('question_id' , '=' , 1)
                        ->where('question_answer','Yes')
                        ->count();
                $yesterday_covid_reports = SurveyAnswer::select('id')
                        ->where('created_at', '>' , $yesterday_start)
                        ->where('created_at', '<' , $yesterday_end)
                        ->where('question_id' , '=' , 1)
                        ->where('question_answer','Yes')
                        ->count();
                $fever = SurveyAnswer::select('id')
                        ->where('created_at', '>' , $today)
                        ->where('question_id' , '=' , 4)
                        ->where('question_answer','>',98)
                        ->count();
                $yesterday_fever = SurveyAnswer::select('id')
                        ->where('created_at', '>' , $yesterday_start)
                        ->where('created_at', '<' , $yesterday_end)
                        ->where('question_id' , '=' , 4)
                        ->where('question_answer','>',98)
                        ->count();
                $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => [
                                'date' => $dateTime,
                                'total_assigned' => $total_assigned,
                                'response_received' => round($response_received),
                                'arrivals_verified' => round($arrivals_verified),
                                'student_denied' => $student_denied,
                                'response_needed' => $response_needed,
                                'student_reported_symtomps' => $student_denied,
                                'new_covid_reports' => $new_covid_reports,
                                'covid_increase' => $new_covid_reports-$yesterday_covid_reports,
                                'fever' => $fever,
                                'fever_increase' => $fever-$yesterday_fever,
                            ],
                            'message'   => 'success'
                                            ]
                    ], 200);

        
                return $response;

            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }            
    }
}
