<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Employer;
use App\Employee;
use App\UserAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Log;
use DB;

class UserAddressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function employee_address($employee_id, Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $employer = Employer::where('user_id', Auth::id())->first();

            $address = UserAddress::select([
                'id',
                'type',
                'street_addr1',
                'street_addr2',
                'village',
                'post_office',
                'police_station',
                'district',
                'near_by',
                'city',
                'state',
                'pincode',
                'country',
                'stayed_from',
                'stayed_to',
                'is_verified'])
            ->where([
                'employee_id' => $employee_id,
                'employer_id' => $employer->id,
                'status' => 'A'
            ])->get();

            if(isset($address) && count($address) > 0){

                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- employee-address/'.$employee_id.' V1 <DEVICE_ID> 200 Success.',
                ]));

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $address,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- employee-address/'.$employee_id.' V1 <DEVICE_ID> 401 No any Address added.',
            ]));

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'No any Address added.',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function add_employee_address(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'employee_id' => 'required',
                'type' => 'required|in:PERMANENT,CURRENT,OLD',
                'pincode' => 'required',
                'country' => 'required',
                'state' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $employer = Employer::where('user_id', Auth::id())->first();

            DB::beginTransaction();      

            $address = new UserAddress;
            $address->employee_id = $request->employee_id;
            $address->employer_id = $employer->id;
            $address->type = $request->type;
            $address->street_addr1 = $request->street_addr1 ?? '';
            $address->street_addr2 = $request->street_addr2 ?? '';
            $address->village = $request->village ?? '';
            $address->post_office = $request->post_office ?? '';
            $address->police_station = $request->police_station ?? '';
            $address->district = $request->district ?? '';
            $address->near_by = $request->near_by ?? '';
            $address->city = $request->city ?? '';
            $address->state = $request->state ?? '';
            $address->pincode = $request->pincode ?? '';
            $address->country = $request->country ?? '';
            $address->save();

            DB::commit();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $address,
                    'message'   => 'Added successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete_employee_address($id)
    {
        try{     
            $allResponse = '';
            $address = UserAddress::find($id);
            $address->status = 'I';
            $address->save();
            
            return response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'Deleted Successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}
