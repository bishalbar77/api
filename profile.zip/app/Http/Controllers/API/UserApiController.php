<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use AWS;
use Carbon\Carbon;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use Aws\Exception\AwsException;
use DB;
use App\Employer;
use App\Employee;
use App\EmployeeReview;
use App\Order;
use App\OrderTask;
use App\TaskHistory;
use App\Uid;
use Geocoder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\User;
use App\UserPref;
use App\DataSource;
use App\UserPic;
use App\Otp;
use App\ApiKey;
use App\ApiActiveSessions;
use App\UserWebProfile;
use App\VerificationType;
use Log;
use Promocodes;
use App\B2bUser;
use App\UploadedDocument;
use App\UserNotification;
use App\Address;
use App\TaskTypeSeverity;
use App\Survey;
use App\SurveyAnswer;
use App\EmployeeEmploymentHistory;
use App\Visitor;
use App\OrderHistory;
use App\OrderType;
use App\TaskType;
use App\UserDoc;
use App\TaskHistoryDoc;
use App\UserAddress;
use App\Mail\WeeklyReport;
use App\Mail\DailyReport;
use Illuminate\Support\Facades\Mail;

class UserApiController extends Controller
{

    /**
     * Create a new user instance after a valid registration.
     *
     * @param array $data
     * @return
     */
    function register(Request $request)
    {
        try{

            $actsession = ApiActiveSessions::where('device_id', $request->device_id)->first();

            $allResponse = json_encode($request->all());

            if(isset($actsession) && !empty($actsession)){
                if($actsession->status == 'I'){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => '',
                            'message' => 'You are not allowed to access.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            } else {
                $actsession = new ApiActiveSessions;
                $actsession->api_version = 'v1';
                $actsession->device_id = $request->input('device_id');
                $actsession->mac_address = $request->input('mac_address');
                $actsession->ip_address = $request->ip();
                $actsession->save();
            }

            $validator = Validator::make($request->all(), [
                'mobile' => 'required|unique:users,mobile',
                'first_name' => 'required',
                'last_name' => 'required',
                'dob' => 'required',
                'gender' => 'required',
                'device_id' => 'required',
                'api_key' => 'required',
                'mac_address' => 'required',
                'source_name' => 'required|in:B2B,B2C,BOT'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $valid_api = ApiKey::where(['api_key' => $request->api_key, 'status' => 'A'])->first();

            if(empty($valid_api->id)){
                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 403 Unauthorized access.',
                ]));
                $response = response()->json([
                    'response' => [
                        'status'    => 403,
                        'data'      => '',
                        'message'   => 'Unauthorized access.',
                    ]
                ], 403);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $user = User::where([
                'mobile' => $this->trim_mobile($request->mobile)
            ])->first();

            if(isset($user) && !empty($user->id)){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => '',
                        'message' => 'You are Already Registered.'
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            if($request->input('send_otp') == 'N'){
                $send_otp = false;
            } else {
                $send_otp = true;
            }

            $otp = rand(1000, 9999);    

            DB::beginTransaction();      

            $datasource = new DataSource;
            $datasource->source_name = $request->input('source_name');
            $datasource->campaign_name = $request->input('campaign_name');
            $datasource->ip_address = $request->ip();
            $datasource->save();

            $user = new User;
            $user->email = $request->input('email');
            $user->email_activation_code = md5($request->email.time());
            $user->password = Hash::make('secret');
            $user->mobile = $this->trim_mobile($request->input('mobile'));
            $user->mobile_otp = $otp;
            $user->first_name = $request->input('first_name');
            $user->middle_name = $request->input('middle_name');
            $user->last_name = $request->input('last_name');
            $user->dob = date('Y-m-d', strtotime($request->input('dob')));
            $user->gender = $request->input('gender');
            $user->data_source_id = $datasource->id;
            $user->save();

            $employer = new Employer;
            $employer->employer_custom_id = rand(1000,9999);
            $employer->email = $request->input('email');
            $employer->email_activation_code = md5($request->email.time());
            $employer->source_type = $request->input('source_name');
            $employer->user_id = $user->id;
            $employer->employer_type = $request->employer_type ?? 'SME';
            $employer->save();

            // if($request->hasFile('photo')) {
            //     $image          = $request->file('photo');
            //     $filename       = $image->getClientOriginalName();
            //     $tempid         = rand(10000,99999);

            //     $s3 = AWS::createClient('s3');
            //     $fileData = $s3->putObject(array(
            //         'Bucket'        => 'cdn.gettruehelp.com',
            //         'Key'           => 'img/'.md5($tempid).$filename,
            //         'SourceFile'    => $request->file('photo'),
            //         'StorageClass'  => 'STANDARD',
            //         'ContentType'   => $request->file('photo')->getMimeType(),
            //         'ACL'           => 'public-read',
            //     ));

            //     if($fileData){
            //         $userpic = new UserPic;
            //         $userpic->employer_id = $employer->id;
            //         $userpic->photo_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
            //         $userpic->is_verified = 'N';
            //         $userpic->save();
            //     }
            // }

            $userpref = new UserPref;
            $userpref->user_id = $user->id;
            $userpref->lang = $request->input('language') == 'en' ? 1 : 2;
            $userpref->save();

            DB::commit();

            if($request->send_otp == 'Y'){
                $this->otp($request->input('mobile'), $otp);
            } else {
                Auth::loginUsingId($user->id);
                $user = Auth::user();
                $user->api_token = $user->createToken('TrueHelp')->accessToken;
                $user->remember_token = Str::random(60);
                $user->mobile_verified_at = date('Y-m-d H:i:s');
                $user->save();

                $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token')->where(['id' => $user->id])->first();
            }

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $user,
                    'message'   => 'Registered successfully'
                ]
            ], 200);
            
            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        } catch (\Exception $e) {
            
            DB::rollback();

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function verify_otp(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $actsession = ApiActiveSessions::where('device_id', $request->device_id)->first();

            if(isset($actsession) && !empty($actsession)){
                if($actsession->status == 'I'){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => '',
                            'message' => 'You are not allowed to access.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            } else {
                $actsession = new ApiActiveSessions;
                $actsession->api_version = 'v1';
                $actsession->device_id = $request->input('device_id');
                $actsession->ip_address = $request->ip();
                $actsession->save();
            }

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'otp' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $mobile = $this->trim_mobile($request->input('mobile'));

            $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token','mobile_otp')->where(['mobile' => $mobile])->first();

            if($user->mobile_otp != $request->otp){

                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Wrong OTP',
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                if(Auth::attempt([
                    'mobile'    => $mobile,
                    'password'  => 'secret'
                ])) {
                    $user = Auth::user();
                    $user->api_token = $user->createToken('TrueHelp')->accessToken;
                    $user->remember_token = Str::random(60);
                    $user->mobile_verified_at = date('Y-m-d H:i:s');
                    $user->save();

                    $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token')->where(['mobile' => $mobile])->first();

                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => $user,
                            'message'   => 'success',
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;

                } else {

                    $response = response()->json([
                        'response' => [
                            'status'    => 500,
                            'data'      => '',
                            'message'   => 'Failed Somthing Wrong',
                        ]
                    ], 500);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => $e->getMessage(),
                    'message'   => 'Failed Somthing Wrong',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function otp($phone, $otp)
    {
        try{

            $SnSclient          = new SnsClient([
                'region'        => 'us-east-1',
                'version'       => '2010-03-31',
                'credentials'   => [
                'key'           => 'AKIA4SH5KM3GHHQL5CUF',
                'secret'        => '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',
                ]
            ]);

            $result = $SnSclient->publish([
                'MessageAttributes' => [
                    'AWS.SNS.SMS.SenderID' => [
                           'DataType' => 'String',
                           'StringValue' => 'TRUEHLP'
                    ]
                 ],
                'Message'     => $otp.' is your TrueHelp OTP code. DO NOT share the OTP with ANYONE.',
                'PhoneNumber' => '+91'.$this->trim_mobile($phone),
            ]);

            return response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => '',
                    'message'   => 'OTP Sent to Registered Number.',
                ]
            ], 200);
            
        } catch (\Exception $e) {
            return response()->json([
                'response' => [
                    'status'    => '500',
                    'data'      => "",
                    'message'   => $e->getMessage()
                ]
            ], 500);
        }
    }

    public function send_otp(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            $actsession = ApiActiveSessions::where('device_id', $request->device_id)->first();

            if(isset($actsession) && !empty($actsession)){
                if($actsession->status == 'I'){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => '',
                            'message' => 'You are not allowed to access.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            } else {
                $actsession = new ApiActiveSessions;
                $actsession->api_version = 'v1';
                $actsession->device_id = $request->input('device_id');
                $actsession->ip_address = $request->ip();
                $actsession->save();
            }

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                        ]
                    ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $mobile = $this->trim_mobile($request->input('mobile'));

            $user = User::where(['mobile' => $mobile])->first();

            if(!isset($user) && empty($user->id)){
                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Not Registered',
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            
            } else {

                $user->mobile_otp = rand(1000, 9999);
                $user->save();

                if($this->otp($request->mobile, $user->mobile_otp)){
                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => $request->mobile,
                            'message'   => 'OTP Sent to Registered Number.',
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                } else {
                    $response = response()->json([
                        'response' => [
                            'status'    => '401',
                            'data'      => $request->mobile,
                            'message'   => 'failed'
                        ]
                    ], 401);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            }
            
        } catch (\Exception $e) {
            
            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $request->mobile,
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function social_login(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());
            $actsession = ApiActiveSessions::where('device_id', $request->device_id)->first();

            if(isset($actsession) && !empty($actsession)){

                if($actsession->status == 'I'){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => '',
                            'message' => 'You are not allowed to access.'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }

            } else {

                $actsession = new ApiActiveSessions;
                $actsession->api_version = 'v1';
                $actsession->device_id = $request->input('device_id');
                $actsession->mac_address = $request->input('mac_address');
                $actsession->ip_address = $request->ip();
                $actsession->save();
            }

            $validator = Validator::make($request->all(), [
                'social_id' => 'required'
            ]);

            if($validator->fails()){
                $request = response()->json([
                    'response' => [
                        'status'    => 'failed',
                        'code'      => 404,
                        'message'   => 'Validation failed',
                        'data'      => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            if($webprofile = UserWebProfile::where('fb_id', $request->social_id)->first()){

                $user = User::where('user_web_profile_id', $webprofile->id)->first();
                
                Auth::loginUsingId($user->id);
                $user = Auth::user();
                $user->api_token = $user->createToken('TrueHelp')->accessToken;
                $user->remember_token = Str::random(60);
                $user->mobile_verified_at = date('Y-m-d H:i:s');
                $user->save();

                $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token')->where(['id' => $user->id])->first();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $user,
                        'message'   => 'success',
                    ]
                ], 200); 

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                $validator = Validator::make($request->all(), [
                    'mobile' => 'required|unique:users,mobile',
                    'first_name' => 'required',
                    'last_name' => 'required',
                    'dob' => 'required',
                    'gender' => 'required',
                    'device_id' => 'required',
                    'source_name' => 'required|in:B2B,B2C,BOT',
                    'social_id' => 'required'
                ]);

                if($validator->fails()){
                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'message' => 'Validation failed',
                            'errors' => $validator->errors()
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
                
                if($request->input('send-otp') == 'N'){
                    $send_otp = false;
                } else {
                    $send_otp = true;
                }

                $otp = rand(1000, 9999);    

                DB::beginTransaction();      

                $datasource = new DataSource;
                $datasource->source_name = $request->input('source_name');
                $datasource->campaign_name = $request->input('campaign_name');
                $datasource->ip_address = $request->ip();
                $datasource->save();

                $user = new User;
                $user->email = $request->input('email');
                $user->email_activation_code = md5($request->email.time());
                $user->password = Hash::make('secret');
                $user->mobile = $this->trim_mobile($request->input('mobile'));
                $user->mobile_otp = $otp;
                $user->first_name = $request->input('first_name');
                $user->middle_name = $request->input('middle_name');
                $user->last_name = $request->input('last_name');
                $user->dob = date('Y-m-d', strtotime($request->input('dob')));
                $user->gender = $request->input('gender');
                $user->data_source_id = $datasource->id;
                $user->save();

                $employer = new Employer;
                $employer->employer_custom_id = rand(1000,9999);
                $employer->email = $request->input('email');
                $employer->email_activation_code = md5($request->email.time());
                $employer->source_type = $request->input('source_name');
                $employer->user_id = $user->id;
                $employer->save();

                // if($request->hasFile('photo')) {
                //     $image          = $request->file('photo');
                //     $filename       = $image->getClientOriginalName();
                //     $tempid         = rand(10000,99999);

                //     $s3 = AWS::createClient('s3');
                //     $fileData = $s3->putObject(array(
                //         'Bucket'        => 'cdn.gettruehelp.com',
                //         'Key'           => 'img/'.md5($tempid).$filename,
                //         'SourceFile'    => $request->file('photo'),
                //         'StorageClass'  => 'STANDARD',
                //         'ContentType'   => $request->file('photo')->getMimeType(),
                //         'ACL'           => 'public-read',
                //     ));

                //     if($fileData){
                //         $userpic = new UserPic;
                //         $userpic->employer_id = $employer->id;
                //         $userpic->photo_url = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                //         $userpic->is_verified = 'N';
                //         $userpic->save();
                //     }
                // }

                $userpref = new UserPref;
                $userpref->user_id = $user->id;
                $userpref->lang = $request->input('language') == 'en' ? 1 : 2;
                $userpref->save();

                DB::commit();

                Auth::loginUsingId($user->id);
                $user = Auth::user();
                $user->api_token = $user->createToken('TrueHelp')->accessToken;
                $user->remember_token = Str::random(60);
                $user->mobile_verified_at = date('Y-m-d H:i:s');
                $user->save();

                $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token')->where(['id' => $user->id])->first();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $user,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'code'      => 404,
                    'message'   => 'Validation failed',
                    'data'      => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function login(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'otp' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                        ]
                    ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $mobile = $this->trim_mobile($request->input('mobile'));

            $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token','mobile_otp')->where(['mobile' => $mobile])->first();

            if($user->mobile_otp != $request->otp){

                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Wrong OTP',
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                if(Auth::attempt([
                    'mobile'    => $mobile,
                    'password'  => 'secret'
                ])) {
                    $user = Auth::user();
                    $user->api_token = $user->createToken('TrueHelp')->accessToken;
                    $user->remember_token = Str::random(60);
                    $user->mobile_verified_at = date('Y-m-d H:i:s');
                    $user->save();

                    $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token')->where(['mobile' => $mobile])->first();

                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => $user,
                            'message'   => 'success',
                        ]
                    ], 200); 

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;

                } else {
                    $response = response()->json([
                        'response' => [
                            'status'    => 500,
                            'data'      => '',
                            'message'   => 'Failed Somthing Wrong',
                        ]
                    ], 500);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => $e->getMessage(),
                    'message'   => 'Failed Somthing Wrong',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function login_b2b(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'email' => 'required',
                'password' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                        ]
                    ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token','mobile_otp')->where(['email' => $request->email])->first();

            if(isset($user) && empty($user->id)){
                $response = response()->json([
                    'response' => [
                        'status'    => 500,
                        'data'      => '',
                        'message'   => 'Email Or Password Not Exists.',
                    ]
                ], 500);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            if(Auth::attempt([
                'email'    => $request->email,
                'password'  => 'secret'
            ])) {
                $user = Auth::user();
                $user->api_token = $user->createToken('TrueHelp')->accessToken;
                $user->remember_token = Str::random(60);
                $user->save();

                $user = User::select('id','first_name','middle_name','last_name','email','mobile','api_token as token')->where(['email' => $request->email])->first();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $user,
                        'message'   => 'success',
                    ]
                ], 200);  

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {
                $response = response()->json([
                    'response' => [
                        'status'    => 500,
                        'data'      => '',
                        'message'   => 'Email Or Password Not Exists.',
                    ]
                ], 500);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => $e->getMessage(),
                    'message'   => 'Failed Somthing Wrong',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function my_employees(){
        try {

            $user = Auth::user();
            $allResponse = '';

            // $revQuery = "SELECT a.id as networkId, b.* FROM networks a LEFT JOIN employees b ON a.worker_id = b.id WHERE a.company_id = '$param_id' AND a.status = '1' GROUP BY a.id ORDER BY a.id DESC";

            // $employees = DB::table('networks a')
            //     ->select('a.id as networkId, b.*')

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $user,
                    'message'   => 'success',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function user_data(Request $request){
        
        try {

            $allResponse = $response->all();

            $user = User::select([
                'users.first_name',
                'users.middle_name',
                'users.last_name',
                'data_sources.source_name as type',
                'users.gender',                
                'employers.id as employer_id',
                'employees.id as employee_id'       
                ])
            ->leftJoin('employers','employers.user_id','=','users.id')
            ->leftJoin('employees','employees.user_id','=','users.id')
            ->leftJoin('data_sources','users.data_source_id','=','data_sources.id')
            ->where([
                'mobile' => $this->trim_mobile($request->mobile)
            ])->get();

            if(isset($user) && !empty($user)){

                Log::info(json_encode([
                    'MSG' => '['.$request->ip().'] -- user-data V1 <DEVICE_ID> 200 Success.',
                ]));

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $user,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 200 No data found for number '.$request->mobile,
            ]));

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'No data found for number '.$request->mobile,
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            return response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);
        }
    }

    public function employer_profile(){
        
        try {

            $user = Auth::user();
            $allResponse = '';

            if(isset($user) && !empty($user->id)){
                
                $employer = Employer::select('id')->where('user_id', $user->id)->first();

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $user,
                        'message'   => 'success',
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }
            
            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- ['.date('Y-m-d H:i:s').'] <employer-data> <V1> <DEVICE_ID> <200> <Profile Successfully get.>',
            ]));

            $response = response()->json([
                'response' => [
                    'status'    => 401,
                    'data'      => '',
                    'message'   => 'failed',
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param array $data
     * @return
     */
    function create_employee(Request $request)
    {
        try{

            $allResponse = json_encode($request->all());

            $employer = Employer::where('email', $request->input('email'))->first();

            if(isset($employer)){
                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Email Already Registered'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $employer = Employer::where('phone', $request->input('mobile'))->first();

            if(isset($employer)){
                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Mobile Number Already Registered'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $otp                        = rand(1000, 9999);

            $employer                   = new Employer;
            $employer->emp_code         = rand(1000,9999);
            $employer->rep_full_name    = $request->input('name');
            $employer->email            = $request->input('email');
            $employer->pass             = Hash::make('secret');
            $employer->address          = $request->input('address');
            $employer->company_name     = $request->input('company_name') ?? $request->input('name');
            $employer->country_code     = $request->input('country_code');
            $employer->phone            = $request->input('mobile');
            $employer->activationcode   = md5($request->email.time());
            $employer->status           = '1';
            $employer->registration_date= date('Y-m-d H:i:s');
            $employer->registered_ip    = $request->ip();
            $employer->work_locations   = $request->input('work_locations');
            $employer->tags             = $request->input('tags');
            $employer->source           = $request->input('source') ?? 'C';             
            $employer->role             = 'EMPLOYER';

            if($request->hasFile('photo')) {
                $image          = $request->file('photo');
                $filename       = $image->getClientOriginalName();
                $tempid         = rand(10000,99999);

                $s3 = AWS::createClient('s3');
                $fileData = $s3->putObject(array(
                    'Bucket'        => 'cdn.gettruehelp.com',
                    'Key'           => 'img/'.md5($tempid).$filename,
                    'SourceFile'    => $request->file('photo'),
                    'StorageClass'  => 'STANDARD',
                    'ContentType'   => $request->file('photo')->getMimeType(),
                    'ACL'           => 'public-read',
                ));

                if($fileData){
                    $employer->photo  = $fileData['ObjectURL'] ? $fileData['ObjectURL'] : '';
                }
            }

            $employer->save();

            $user                   = new User;
            $user->name             = $request->input('name');
            $user->email            = $request->input('email');
            $user->mobile           = $request->input('mobile');
            $user->password         = Hash::make('secret');
            $user->api_token        = Str::random(60);
            $user->employer_id      = $employer->id;
            $user->is_super_admin   = '0';
            $user->roles            = 'EMPLOYER';
            $user->otp              = $otp;
            $user->save();

            $this->otp($employer->country_code.$employer->phone, $otp);

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $user->mobile,
                    'message'   => 'Registered successfully'
                ]
            ], 200);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => '',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    private function trim_mobile($mobile){
        
        $mobile = str_replace("+","", $mobile);
        
        $length = strlen($mobile);
        
        if($length == 11){
            $mobile = substr($mobile, 1);
        } elseif($length == 12) {
            $mobile = substr($mobile, 2);                
        } elseif($length == 13) {
            $mobile = substr($mobile, 3);                
        }

        return $mobile;
    }

    public function get_profile()
    {
        # code...
    }

    public function login_response(){
        return response()->json([
            'response' => [
                'status'    => 401,
                'data'      => '',
                'message'   => 'Please Pass API Token'
            ]
        ], 401);
    }

    public function verify_number(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'api_key' => 'required',
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $send_otp = $request->send_otp ?? 'N';
            
            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){
                 
                 if($this->validate_mobile($request->mobile) == false){    

                    $response = response()->json([
                        'response' => [
                            'status' => 401,
                            'data' => 'VALIDATION_FAILS',
                            'message' => 'Please Provide Valid Mobile Number'
                        ]
                    ], 400);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                
                } elseif($send_otp == 'Y') {
                    
                    $otp = rand(1000, 9999);
                    $mobile = $this->trim_mobile($request->mobile);

                    $existingUser = Otp::where('medium', $mobile)->first();

                    if(isset($existingUser->id)){
                        $existingUser->medium_code = $otp;
                        $existingUser->is_verified = 'N';
                        $existingUser->save();
                    } else {
                        $otps = new Otp;
                        $otps->medium = $mobile;
                        $otps->medium_code = $otp;
                        $otps->is_verified = 'N';
                        $otps->save();
                    }

                    $this->otp($this->trim_mobile($request->mobile), $otp);

                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => [
                                                'otp' => $otp
                                            ],
                            'message'   => 'OTP Sent Successfully'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;

                } else {

                    $response = response()->json([
                        'response' => [
                            'status' => 200,
                            'data' => 'SUCCESS',
                            'message' => 'Mobile Number Validated Successfully'
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }

            } else {

                $response = response()->json([
                    'response' => [
                        'status' => 403,
                        'data' => 'VALIDATION_FAILS',
                        'message' => 'Unauthorized Access'
                    ]
                ], 403); 

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function otp_verify(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'mobile' => 'required',
                'otp' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $get_info = $request->get_info ?? 'N';

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $otp = $request->otp;
                $mobile = $this->trim_mobile($request->mobile);
                $existingUser = Otp::where('medium', $mobile)->first();

                if(isset($existingUser->id)){
                    
                    if($existingUser->medium_code == $otp){
                        
                        $existingUser->is_verified = 'Y';
                        $existingUser->save();

                        if($get_info == 'Y'){
                            
                            if(Auth::attempt([
                                'mobile'    => $mobile,
                                'password'  => 'secret'
                            ])) {
                                $user = Auth::user();
                                $user->api_token = $user->createToken('TrueHelp')->accessToken;
                                $user->remember_token = Str::random(60);
                                $user->mobile_verified_at = date('Y-m-d H:i:s');
                                $user->save();
                            }

                            $user = DB::table('users')->select([
                                'users.id',
                                'users.first_name',
                                'users.middle_name',
                                'users.last_name',
                                'data_sources.source_name as type',
                                'users.gender',
                                'users.api_token',                
                                'users.remember_token',                
                                'employers.id as employer_id',
                                'employees.id as employee_id'       
                                ])
                            ->leftJoin('employers','employers.user_id','=','users.id')
                            ->leftJoin('employees','employees.user_id','=','users.id')
                            ->leftJoin('data_sources','users.data_source_id','=','data_sources.id')
                            ->where([
                                'users.mobile' => $this->trim_mobile($request->mobile)
                            ])->get();

                            if(count($user) > 0){
                                $response = response()->json([
                                    'response' => [
                                        'status'    => 200,
                                        'data'      => $user,
                                        'message'   => 'OTP Verified Successfully'
                                    ]
                                ], 200);

                                \LogActivity::addToLog($allResponse, $response);
                
                                return $response;
                            }

                            $response = response()->json([
                                'response' => [
                                    'status'    => 200,
                                    'data'      => 'SUCCESS',
                                    'message'   => 'OTP Verified Successfully'
                                ]
                            ], 200);

                            \LogActivity::addToLog($allResponse, $response);
                
                            return $response;

                        } else {
                            
                           $response = response()->json([
                                'response' => [
                                    'status'    => 200,
                                    'data'      => 'SUCCESS',
                                    'message'   => 'OTP Verified Successfully'
                                ]
                            ], 200); 

                           \LogActivity::addToLog($allResponse, $response);
                
                            return $response;
                       }
                    
                    } else {
                        
                        $response = response()->json([
                            'response' => [
                                'status'    => 400,
                                'data'      => 'FAILED',
                                'message'   => 'OTP Not Matched'
                            ]
                        ], 200);

                        \LogActivity::addToLog($allResponse, $response);
                
                        return $response;
                    }

                } else {

                    $response = response()->json([
                        'response' => [
                            'status' => 403,
                            'data' => 'VALIDATION_FAILS',
                            'message' => 'Unauthorized Access'
                        ]
                    ], 403); 

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }

            } else {

                $response = response()->json([
                    'response' => [
                        'status' => 403,
                        'data' => 'VALIDATION_FAILS',
                        'message' => 'Unauthorized Access'
                    ]
                ], 403);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
                
            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function create_promocode(Request $request)
    {
        $amount = $request->amount;
        $reward = $request->reward;
        $data = [
            'description' => $request->description,
            'type' => $request->type
        ];
        $expires_in = date('Y-m-d H:i:s', strtotime($request->expires_in));
        $quantity = $request->quantity;

        Promocodes::create($amount, $reward, $data, $expires_in, $quantity, $is_disposable = false);
    }

    public function apply_promocode(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());
        
            $user = User::find(Auth::id());
            $check = Promocodes::check($request->code);

            if($check->exists() == 1) {

                $promocode = $user->redeemCode($request->code);
                unset($promocode->users);

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $promocode,
                        'message'   => 'Promocode Applyed Successfully'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => 'FAILED',
                        'message'   => 'Mobile Not Registered'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function validate_mobile($mobile)
    {
        return preg_match('/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/', $mobile);
    }

    public function profile_summary($id)
    {
        try {

            $allResponse = '';

            $user = User::whereRaw('md5(users.id) = "' . $id . '"')
                ->leftJoin('employees', 'users.id', '=', 'employees.user_id')
                ->leftJoin('employee_types', 'employees.employee_type_id', '=', 'employee_types.id')
                ->select('users.id','users.first_name', 'users.middle_name', 'users.last_name','users.mobile','employees.id as employee_id', 'employee_types.type', 'user_pics.photo_url','employees.employee_custom_id')
                ->leftJoin('user_pics', function($query) {
                    $query->on('employees.id','=','user_pics.employee_id')
                        ->whereRaw('user_pics.id IN (select MAX(a2.id) from user_pics as a2 join employees as u2 on u2.id = a2.employee_id group by u2.id)');
                    })
                ->first();

            $reviews = EmployeeReview::where('employee_id', $user->employee_id)->get();

            $employment = DB::table('employee_employment_history')
                ->leftJoin('employers', 'employee_employment_history.employed_by', '=', 'employers.id')
                ->leftJoin('users', 'employers.user_id', '=', 'users.id')
                ->where('employee_id', $user->employee_id)
                ->select('users.first_name','users.middle_name','users.last_name','employers.b2b_company_name','employers.b2b_brand_name','employee_employment_history.salary','employee_employment_history.employment_start','employee_employment_history.employment_stop','employers.employer_custom_id', 'employee_employment_history.created_at as emp_add_date', 'employee_employment_history.verification_date', 'employee_employment_history.employment_start', 'employee_employment_history.employment_stop', 'employee_employment_history.is_verified', 'employee_employment_history.employee_id')
                ->get();
            
            $tasks = OrderTask::where('employee_id', $user->employee_id)
                ->leftJoin('task_history', function($query) {
                    $query->on('order_tasks.id','=','task_history.task_id')
                        ->whereRaw('task_history.id IN (select MAX(a2.id) from task_history as a2 join order_tasks as u2 on u2.id = a2.task_id group by u2.id order by u2.id desc)');
                    })
                ->select('order_tasks.task_display_id', 'order_tasks.status', 'task_history.antecedants_data')
                ->get();
            
            $verifications = array();

            foreach($tasks as $key => $task){
                if($task->task_display_id == 'AADHAAR_VERIFICATION' || $task->task_display_id == 'PAN_VERIFICATION' || $task->task_display_id == 'DL_VERIFICATION')
                $verifications['NID'][$key] = $task;
                if($task->task_display_id == 'EDUCATION_VERIFICATION')
                $verifications['EDUCATION_VERIFICATION'][$key] = $task;
                if($task->task_display_id == 'EMPLOYMENT_CHECK')
                $verifications['EMPLOYMENT'][$key] = $task;
                if($task->task_display_id == 'AV_POSTAL' || $task->task_display_id == 'AV_PHYSICAL' || $task->task_display_id == 'AV_DIGITAL')
                $verifications['AV'][$key] = $task;
                if($task->task_display_id == 'CRC')
                $verifications['CRC'][$key] = $task;
            }

            if(isset($user->id)) {

                $response = response()->json([
                    'response' => [
                        'status' => 200,
                        'user' => $user,
                        'employment' => $employment,
                        'reviews' => $reviews,
                        'verifications' => $tasks,                        
                        'verification_details' => $verifications,                        
                        'message' => 'Success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => 'FAILED',
                        'message'   => 'User Not Found'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            }

        } catch (\Exception $e) {
            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => 'FAILED',
                    'message'   => $e->getMessage()
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }


    public function login_by_email_pass(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'email' => 'required',
                'password' => 'required',
                'api_key' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                if($b2b_user = B2bUser::where('email', $request->email)->first()){

                    if($b2b_user->password != md5($request->password)){
                        $response = response()->json([
                            'response' => [
                                'status'    => 401,
                                'data'      => '',
                                'message'   => 'Wrong Password Inserted',
                            ]
                        ], 200);

                        \LogActivity::addToLog($allResponse, $response);
                    
                        return $response;
                    }

                    $user = User::find($b2b_user->user_id);
                    Auth::login($user);

                    $user = Auth::user();
                    $user->api_token = $user->createToken('TrueHelp')->accessToken;
                    $user->remember_token = Str::random(60);
                    $user->save();

                    $response = response()->json([
                        'response' => [
                            'status'    => 200,
                            'data'      => $user,
                            'message'   => 'Logged in Successfully',
                        ]
                    ], 200);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;

                } else {

                    $response = response()->json([
                        'response' => [
                            'status'    => 401,
                            'data'      => '',
                            'message'   => 'Email Not Registered',
                        ]
                    ], 500);

                    \LogActivity::addToLog($allResponse, $response);
                
                    return $response;
                }
                
            } else {                        
                
                $response = response()->json([
                    'response' => [
                        'status'    => 400,
                        'data'      => '',
                        'message'   => 'Api Key Not Verified;'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => $e->getMessage(),
                    'message'   => 'Failed Somthing Wrong',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function email_employer(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'api_key' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $b2b_users = B2bUser::all();
                $mailAddress[]=NULL;$count=0;
                foreach($b2b_users as $b2b_user)
                {
                    $user = User::find($b2b_user->user_id);
                    if(isset($user) && !empty($user->id))
                    {
                        Auth::login($user);

                        $user = Auth::user();
                        $user->api_token = $user->createToken('TrueHelp')->accessToken;
                        $user->remember_token = Str::random(60);
                        $user->save();

                        $employee = Employee::where('user_id', Auth::id())->first();
                        $empInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employee->id)->first();
                        $employer = Employer::find($empInfo->employed_by);
                        $value = $employer->email;
                        if(array_search($value,$mailAddress,true)===false)
                        {
                            $mailAddress[$count]=$employer->email;
                            $count++;
                            $data = array(
                                'api_token' => $user->api_token,
                            );
                            Mail::to($employer->email)->send(new WeeklyReport($data));
                        }
                        // Mail::to($user->email)->send(new WeeklyReport($data));
                    }
                }

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $mailAddress,
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Email Not Registered',
                    ]
                ], 500);

                \LogActivity::addToLog($allResponse, $response);
            
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => $e->getMessage(),
                    'message'   => 'Failed Somthing Wrong',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }

    public function daily_report_email(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $validator = Validator::make($request->all(), [
                'api_key' => 'required'
            ]);

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'message' => 'Validation failed',
                        'errors' => $validator->errors()
                    ]
                ], 400);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $apikey = ApiKey::where([
                'api_key' => $request->api_key,
                'status' => 'A'
            ])->first();

            if(isset($apikey) && !empty($apikey->id)){

                $b2b_users = B2bUser::all();
                $mailAddress[]=NULL;$count=0;
                foreach($b2b_users as $b2b_user)
                {
                    $user = User::find($b2b_user->user_id);
                    if(isset($user) && !empty($user->id))
                    {
                        Auth::login($user);

                        $user = Auth::user();
                        $user->api_token = $user->createToken('TrueHelp')->accessToken;
                        $user->remember_token = Str::random(60);
                        $user->save();

                        $employee = Employee::where('user_id', Auth::id())->first();
                        $empInfo = EmployeeEmploymentHistory::select('employed_by')->where('employee_id', $employee->id)->first();
                        $employer = Employer::find($empInfo->employed_by);
                        $value = $employer->email;
                        if(array_search($value,$mailAddress,true)===false)
                        {
                            $mailAddress[$count]=$employer->email;
                            $count++;
                            $data = array(
                                'api_token' => $user->api_token,
                            );
                            Mail::to($employer->email)->send(new DailyReport($data));
                        }
                        // Mail::to($user->email)->send(new DailyReport($data));
                    }
                }

                $response = response()->json([
                    'response' => [
                        'status'    => 200,
                        'data'      => $mailAddress,
                        'message'   => 'success'
                    ]
                ], 200);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;

            } else {

                $response = response()->json([
                    'response' => [
                        'status'    => 401,
                        'data'      => '',
                        'message'   => 'Email Not Registered',
                    ]
                ], 500);

                \LogActivity::addToLog($allResponse, $response);
            
                return $response;
            }

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 500,
                    'data'      => $e->getMessage(),
                    'message'   => 'Failed Somthing Wrong',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}