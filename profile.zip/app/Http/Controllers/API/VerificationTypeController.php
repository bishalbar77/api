<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\VerificationType;

class VerificationTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            $allResponse = json_encode($request->all());

            $verification_types = VerificationType::select([
                'name',
                'amount',
                'icon_url',
                'description',
                'tat'
                ])
            ->where(['source' => $request->source, 'status' => 'A'])->get();

            $response = response()->json([
                'response' => [
                    'status'    => 200,
                    'data'      => $verification_types,
                    'message'   => 'success',
                ]
            ], 200);

            $allResponse['get_response'] = $verification_types;

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;

        } catch (\Exception $e){

            $response = response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => $e->getMessage(),
                    'message'   => 'failed',
                ]
            ], 500);

            \LogActivity::addToLog($allResponse, $response);
                
            return $response;
        }
    }
}
