<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use AWS; 
use Aws\Exception\AwsException;
use Illuminate\Support\Facades\Validator;
use App\Employer;
use App\Employee;
use App\ApiKey;
use App\Survey;
use App\User;
use DB;
use Aws\S3\S3Client; 
use Aws\Sns\SnsClient; 
use App\EmployeeEmploymentHistory;
use App\UserNotification;
use App\Visitor;
use Auth;

class VisitorController extends Controller
{
    public function get_visitors(Request $request)
    {
        try{

            $visitors = Visitor::get();

            if($visitors){
                return response()->json([
                    'response' => [
                        'status'  => 'success',
                        'message' => '',
                        'data'    => $visitors,
                    ]
                ], 200);
            } else {
                return response()->json([
                    'response' => [
                        'status'    => 'failed',
                        'message'   => 'Not Found',
                        'data'      => "",
                    ]
                ], 500);
            }

        } catch (\Exception $e) {
            return response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => "",
                    'message'   => $e->getMessage()
                ]
            ], 500);
        }
    }

    public function store_visitor(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'employer_id' => 'required',
                'first_name' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $visitor = new Visitor;
            $visitor->employer_id = $request->employer_id;
            $visitor->first_name = $request->first_name;
            $visitor->middle_name = $request->middle_name;
            $visitor->last_name = $request->last_name;
            $visitor->mobile = $request->mobile;
            $visitor->country_code = $request->country_code;
            $visitor->frequency = $request->frequency;
            $visitor->lang = $request->lang;
            $visitor->time_zone = $request->time_zone;
            $visitor->status = $request->status;
            $visitor->save();

             $employers = Employer::where('id', $request->employer_id)
                ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
                ->first();

            DB::beginTransaction();

            $survey = new Survey;
            $survey->survey_type = 'HEALTH_CHECK';
            $survey->visitor_id = $visitor->id;
            $survey->employer_id = $employers->employer_id;
            $survey->save();

            $SnSclient          = new SnsClient([
                'region'        => 'us-east-1',
                'version'       => '2010-03-31',
                'credentials'   => [
                'key'           => 'AKIA4SH5KM3GOZGMNHLP',
                'secret'        => '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',
                ]
            ]);

            $brand = $employers->b2b_brand_name ? ' ('.$employers->b2b_brand_name.')' : '';
            $company = $employers->b2b_company_name.' '.$brand;
            $message = 'Hi '.$visitor->first_name.', Health Screening Available from '.$company.'. Please complete the screening before departing for the Day. Have a Nice Day. https://www.gettruehelp.com/healthcheck/?eid='.md5($visitor->id);

            $result = $SnSclient->publish([
                'Message'     => $message,
                'PhoneNumber' => '+91'.$request->mobile,
            ]);

            DB::commit();

            return response()->json([
                'response' => [
                    'status'  => 'success',
                    'message' => '',
                    'data'    => $visitor,
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => "",
                    'message'   => $e->getMessage()
                ]
            ], 500);
        }
    }

    public function add_visitor(Request $request, $employer_id)
    {
        $employers = Employer::whereRaw('md5(id) = "' . $employer_id . '"')
            ->select('employer_custom_id','b2b_company_name','b2b_brand_name','id as employer_id')
            ->first();

        try {

            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'mobile' => 'required'
            ]);

            $allResponse = json_encode($request->all());

            if($validator->fails()){
                $response = response()->json([
                    'response' => [
                        'status' => 401,
                        'data' => 'VALIDATION_FAILS',
                        'message' => $validator->errors()
                    ]
                ], 401);

                \LogActivity::addToLog($allResponse, $response);
                
                return $response;
            }

            $visitor = new Visitor;
            $visitor->employer_id = $employers->employer_id;
            $visitor->first_name = $request->first_name;
            $visitor->middle_name = $request->middle_name ?? '';
            $visitor->last_name = $request->last_name;
            $visitor->mobile = $request->mobile;
            $visitor->country_code = $request->country_code ?? 91;
            $visitor->frequency = $request->frequency ?? '';
            $visitor->lang = $request->lang ?? 1;
            $visitor->time_zone = $request->time_zone ?? '';
            $visitor->person_to_meet = $request->person_to_meet ?? '';
            $visitor->reason = $request->reason ?? '';
            $visitor->status = $request->status ?? '';            
            $visitor->save();

            DB::beginTransaction();

            $survey = new Survey;
            $survey->survey_type = 'HEALTH_CHECK';
            $survey->visitor_id = $visitor->id;
            $survey->employer_id = $employers->employer_id;
            $survey->save();

            DB::commit();

            return response()->json([
                'response' => [
                    'status'  => 'success',
                    'message' => '',
                    'data'    => $visitor,
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'response' => [
                    'status'    => 'failed',
                    'data'      => "",
                    'message'   => $e->getMessage()
                ]
            ], 500);
        }
    }
}