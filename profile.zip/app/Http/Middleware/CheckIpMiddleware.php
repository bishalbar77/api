<?php

namespace App\Http\Middleware;

use Log;
use Closure;

class CheckIpMiddleware
{
    public $whiteIps = ['172.31.41.253','172.31.12.230','127.0.0.1','::1','172.31.11.225'];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!in_array($request->ip(), $this->whiteIps)) {

            Log::info(json_encode([
                'MSG' => '['.$request->ip().'] -- employer-data V1 <DEVICE_ID> 200 Unauthorize access. Filter By White listed IPs.',
            ]));
            
            return response()->json([
                'response' => [
                    'status'    => 403,
                    'data'      => '',
                    'message'   => 'Unauthorize access',
                ]
            ], 403);
        }    
        return $next($request);
    }
}
