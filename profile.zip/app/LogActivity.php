<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class LogActivity extends Model
{
    protected $fillable = [
        'subject', 
        'post_data', 
        'api_response',
        'url', 
        'method', 
        'ip', 
        'agent', 
        'user_id',
        'current_location', 
        'logger_name', 
    ];

}
