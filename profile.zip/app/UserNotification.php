<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserNotification extends Model
{
	protected $table = 'user_notifications';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'nf_medium',
		'nf_to',
		'nf_message',
		'nf_action_url',
        'nf_is_sent',
        'nf_sent_on',
        'is_seen'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    static public function saveNotification($employer_id,$nf_message,$eid){
        $user_notifications = new UserNotification;
        $user_notifications->nf_medium = "B2B_APP";
        $user_notifications->nf_to = $employer_id;
	$user_notifications->nf_action_url = $eid;
        $user_notifications->nf_message = $nf_message;
        $user_notifications->save();
    }

}
