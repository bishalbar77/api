<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPref extends Model
{
	protected $table = 'user_prefs';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'employee_id',
		'employer_id',
		'user_id',
		'lang',
		'notify_by_sms',
		'notify_by_email',
		'notify_by_wa'
    ];
}
