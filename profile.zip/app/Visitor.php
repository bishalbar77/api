<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
	protected $table = 'visitors';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'employer_id',
		'first_name',
		'middle_name',
		'last_name',
		'mobile',
		'country_code',
		'frequency',
		'lang',
		'time_zone',
		'status',
    ];
}
