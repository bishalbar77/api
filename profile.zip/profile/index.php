<?php
$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$parts = parse_url($url);
parse_str($parts['query'], $query);
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "https://api.gettruehelp.com/api/profile-summary/".$query['id']);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$data = curl_exec($curl);
curl_close($curl);

$dataArr = json_decode($data, true);

$first_name = $dataArr['response']['user']['first_name'] ?? '';
$middle_name = $dataArr['response']['user']['middle_name'] ?? '';
$last_name = $dataArr['response']['user']['last_name'] ?? '';
$mobile = $dataArr['response']['user']['mobile'] ?? '';

$type = $dataArr['response']['employee']['type'] ?? '';
$reviews = $dataArr['response']['reviews'];
$employment = $dataArr['response']['employment'];

$aadhar_verifications = $dataArr['response']['verification_history']['AADHAAR_VERIFICATION'];
$aadhar_verifications_anc = $aadhar_verifications['data']['antecedants_data'] ?? '';
$aadhar_verifications_ancd = json_decode($aadhar_verifications_anc, true);

$address = $dataArr['response']['verification_history']['AV_POSTAL'];
$address_anc = $address['data']['antecedants_data'] ?? '';
$address_ancd = json_decode($address_anc, true);

$crc = $dataArr['response']['verification_history']['CRC'];
$crc_anc = $crc['data']['antecedants_data'] ?? '';
$crc_ancd = json_decode($crc_anc, true);

$userpics = $dataArr['response']['userpics'];
$employee = $dataArr['response']['employee'];

foreach ($reviews as $key => $review) {
   $avrage[] = $review['rating'];
}

$total_reviews = $reviews ? count($reviews) : 0;
$avrage_rating = array_sum($avrage) / $total_reviews;
$full_name = $first_name.' '.$middle_name.' '.$last_name;
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
<!DOCTYPE html>
<html>
   <head>
      <title><?php echo $full_name; ?>'s Profile Summary -- TrueHelp</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="css/bootstrap.css" type="text/css" rel="stylesheet">
      <link href="css/mdb.css" type="text/css" rel="stylesheet">
      <link href="css/style.css" type="text/css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="css/font.css" type="text/css" rel="stylesheet">
   </head>
   <body  style="background-color: rgb(14 33 56);">
      <center><h2 class="font-weight-bold my-3" ><img src = "images/logo1.png" class="im1"> TRUEHELP VERIFIED REPORT</h2></center>

      <div class="container col-lg-11">
         <div class="container my-8 py-2 col-lg-12 prof">
            <div class="col-md-12 mb-4 mb-md-0 " >
               <div class="amazon">
                  <?php if(!empty($userpics) && isset($userpics['photo_url'])): ?>
                     <img src="<?php echo $userpics['photo_url']; ?>" class="rounded-circle im im2" style="max-width: 224px;">
                  <?php else: ?>
                     <img src="images/photo.jpg" class="rounded-circle im im2">
                  <?php endif; ?>

                  <div class="amazon-content">
                     <h3 class="full-bl"><?php echo $full_name ?></h3>
                     <h5 class="si1 pro-wgt"><img src="images/steeringWheel2.png" class="img2">&nbsp <?php echo $type; ?></h5> 
                     <h5 class="si1 pro-wgt"><img src="images/phone.png" class="img2"> &nbsp +91-<?php echo $mobile ?></h5>
                     <h5 class="si1 shade-bl" >
                        <span class="star-ra">
                           <span class="fa fa-star <?php echo $avrage_rating >= 1 ? 'checked' : '' ?>"></span>
                           <span class="fa fa-star <?php echo $avrage_rating >= 2 ? 'checked' : '' ?>"></span>
                           <span class="fa fa-star <?php echo $avrage_rating >= 3 ? 'checked' : '' ?>"></span>
                           <span class="fa fa-star <?php echo $avrage_rating >= 4 ? 'checked' : '' ?>"></span>
                           <span class="fa fa-star <?php echo $avrage_rating >= 5 ? 'checked' : '' ?>"></span>
                        </span> <?php echo $total_reviews ?> Reviews</h5>
                     </div>
                  </div>
               </div>

               <!--At a Glance-->
               <div class="container my-3 py-4 z-depth-1 col-lg-12 con-radius"  >
                  <section class="px-md-3 mx-md-3  text-lg-left dark-grey-text" >
                     <section class="at-a-glance-margin"> 
                     <h3 class="full-bl" >At a Glance</h3>
                     <br>
                     <h5 class="re" style="color: <?php color($aadhar_verifications['data']['severity'] ?? '') ?>;">
                        <img src="images/press.png" class="img1"> <?php echo $aadhar_verifications['data']['severity'] ?> case in ID Verification
                     </h5>
                     <h5 class="gr">
                        <img src="images/work.png" class="img1">  Employment history Not verified
                     </h5>
                     <h5 class="re" style="color: <?php color($address['data']['severity'] ?? '') ?>">
                        <img src="images/pin.png" class="img1"> <?php echo $address['data']['severity'] ?> case in address Verification
                     </h5>
                     <h5 class="gr">
                        <img src="images/crime.png" class="img1" style="color: <?php color($crc['data']['severity'] ?? '') ?>"> <?php echo $crc['data']['severity'] ?> Case in Criminal Record
                     </h5>
                     </section>
                  </section>
               </div>

               <!--ID verification-->
               <section class="margin-sec">
                  <h3 class="re" style="color: <?php color($aadhar_verifications['data']['severity'] ?? '') ?>;">
                     <img src="images/press.png" class="img1"> ID Verification
                  </h3>
                  <br/>
                  <h5>
                     <div class="d-flex align-items-stretch">
                        <div class="w-100 medium-bl ">
                           <img src="images/group1.png" class="img1">Aadhar Verification
                        </div>
                        <div class="flex-grow-1 fl" style="color: <?php color($aadhar_verifications['data']['severity'] ?? '') ?>;"><?php echo $aadhar_verifications['data']['severity'] ?> CASE</div>
                     </div>
                  </h5>
                  <p>XXXX-XXXX-XXXX-<?php echo substr($aadhar_verifications_ancd['aadhar_number']['value'], -4); ?></p>
                  <div class="d-flex align-items-stretch">
                     <div class="w-75">
                        <p><?php echo $aadhar_verifications_ancd['conclusion'] ?? '' ?></p>
                     </div>
                     <div class="flex-grow-1 fl" ></div>
                  </div>
                  <h6 class="font-weight-bold">
                        <ref style=" color:  rgb(153 153 153);">Last verified on <?php echo $aadhar_verifications_ancd['verification_date'] ? date('d/m/Y', strtotime($crc_ancd['verification_date'])) : '' ?></ref>
                     </h6>
               </section>
               <hr>

               <!--Employment verification-->
               <section class="margin-sec">
                  <h3 class="gr">
                     <img src="images/work.png" class="img1"> Employment Verification
                  </h3>
                  <br/>
                  <?php if(count($employment) > 0): ?>
                     <?php foreach ($employment as $key => $empl): ?>
                        <h5>
                           <div class="d-flex align-items-stretch ">
                              <div class="w-100 medium-bl">
                                 <img src="images/group2.png" class="img1">
                                 <?php 
                                    if(!empty($empl['b2b_company_name'])):
                                       echo $empl['b2b_company_name']; 
                                       if(!empty($empl['b2b_brand_name'])):
                                          echo '--'.$empl['b2b_brand_name'];
                                       endif;
                                    else :
                                       echo $empl['first_name'].' '.$empl['middle_name'].' '.$empl['last_name'];
                                    endif;
                                 ?>
                              </div>
                              <div class="flex-grow-1 fl" style="color: <?php color($aadhar_verifications['data']['severity'] ?? '') ?>;"><?php echo $aadhar_verifications['data']['severity'] ?> CASE</div>
                           </div>
                        </h5>
                        <p>Worked as a <?php echo $type; ?></p>
                        <p>From <?php echo date('d/m/Y', strtotime($empl['employment_start'])) ?></p>
                        <h6  class="font-weight-bold">
                           <ref style=" color:  rgb(153 153 153)">Last verified on <?php echo date('d/m/Y', strtotime($empl['created_at'])) ?></ref>
                        </h6>
                     <?php endforeach; ?>
                  <?php endif; ?>
               </section>
               <hr>

               <!--Address verification-->
               <section class="margin-sec">
                  <div class="d-flex align-items-stretch">
                     <div class="w-100 medium-bl">
                        <h3 class="re" >
                           <img src="images/pin.png" class="img1">Address Verification
                        </h3>
                     </div>
                  </div>
                  <br/>
                  <h5>
                     <div class="d-flex align-items-stretch">
                        <div class="w-100 medium-bl">
                           <img src="images/group2.png" class="img1">Current Address
                        </div>
                        <div class="flex-grow-1 fl" style="color: <?php color($address['data']['severity'] ?? '') ?>;"><?php echo $address['data']['severity'] ?> CASE</div>
                     </div>
                  </h5>
                  <p><?php echo $address_ancd['address']['value'] ?? '' ?></p>
                  <p><?php echo $address_ancd['conclusion'] ?? '' ?></p>
                  <h6 class="font-weight-bold">
                     <ref style=" color:  rgb(153 153 153);">Last verified on <?php echo $address_ancd['verification_date'] ? date('d/m/Y', strtotime($address_ancd['verification_date'])) : '' ?></ref>
                  </h6>
               </section>
               <hr>

               <!--crime verification-->
               <section class="margin-sec">
                  <h3 class="gr" style="color: <?php color($crc['data']['severity'] ?? '') ?>;">
                     <img src="images/crime.png" class="img1"> Criminal Record Verification
                  </h3>
                  <br/>
                  <h5>
                     <div class="d-flex align-items-stretch">
                        <div class="w-100 medium-bl">
                           <img src="images/group1.png" width="25px" height="25px" class="img1"> <?php echo $crc_ancd['address']['value'] ?? '' ?>
                        </div>
                        <div class="flex-grow-1 fl re" style="color: <?php color($crc['data']['severity'] ?? '') ?>;"><?php echo $crc['data']['severity'] ?? ''; ?> CASE</div>
                     </div>
                  </h5>
                  <div class="d-flex align-items-stretch ">
                     <div class="w-75 f1">
                        <p><?php echo $crc_ancd['conclusion'] ?? '' ?></p>
                     </div>                     
                     <div class="flex-grow-1" fl></div>
                  </div>
                  <h6 class="font-weight-bold">
                     <ref style=" color:  rgb(153 153 153);">Last verified on <?php echo $crc_ancd['verification_date'] ? date('d/m/Y', strtotime($crc_ancd['verification_date'])) : '' ?></ref>
                  </h6>
               </section>
               <hr>

               <!--qr code and footer-->
               <center><h4 class="bl" >This report is computer generated and does not require a signature*</h4></center>
               <hr>
               <center><h4 class="blu" >To get more details, visit www.gettruehelp.com or scan this QR code</h4></center>
               <br/>
               <center>
                  <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?php echo $url; ?>&choe=UTF-8" title="Link to Google.com" style="max-width: 250px;" class="imgqr"/>
               </center> 
            </div>
         </div>
      <center><h4 class="font-weight-bold wi ">Report last generated on <?php echo date('d M Y H:i'); ?></h4></center></center>
   </body>
</html>
<?php
function color($status) {
   switch ($status) {
      case "YELLOW":
         echo "#ffc107";
         break;
      case "GREEN":
         echo "#63b152";
         break;
      case "RED":
         echo "#e45055";
         break;
      default:
         echo "#665c52";
   }
}