<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => 'throttle:60'], function () {

	Route::middleware('auth:api')->get('/user', function (Request $request) {
	    return $request->user();
	});

	//employers specific api
	Route::post('add-visitor/{id}', 'API\VisitorController@add_visitor');
	Route::post('get-employer-details', 'API\EmployerController@details');
	Route::post('post-visitor-survey-answer', 'API\SurveyController@post_visitor_survey_answer');

	Route::post('register', 'API\UserController@register');
	Route::post('login', 'API\UserController@login');
	Route::get('login', 'API\UserApiController@login_response')->name('login');
	Route::post('otp-verify', 'API\UserApiController@otp_verify');
	Route::post('create-promocode', 'API\UserApiController@create_promocode');
	Route::post('verify-number', 'API\UserApiController@verify_number');
	Route::get('profile-summary/{id}', 'API\UserApiController@profile_summary');

	Route::post('weekly-report-email', 'API\UserApiController@email_employer');
	Route::post('daily-report-email', 'API\UserApiController@daily_report_email');

	Route::middleware('auth:api')->group(function(){
	    Route::resource('users', 'API\UserController');
	});

	Route::post('register-employer', 'API\UserApiController@register');
	Route::post('verify-otp', 'API\UserApiController@verify_otp');
	Route::post('login-employer', 'API\UserApiController@login');
	Route::post('login-employer-b2b', 'API\UserApiController@login_b2b');
	Route::post('send-otp', 'API\UserApiController@send_otp');
	Route::post('social-login', 'API\UserApiController@social_login');
	
	Route::post('register-employee', 'API\EmployeeController@register');
	
	Route::post('documents-types', 'API\DocumentTypeController@index');
	Route::post('employee-types', 'API\EmployeeTypeController@index');

	// Route::middleware(['checkIp'])->group(function () {
		Route::post('user-data', 'API\UserApiController@user_data');
		Route::post('employer-data', 'API\EmployerController@employer_data');
		Route::post('employee-data', 'API\EmployeeController@employee_data');
	// });

	Route::post('/login-otp', 'API\ApiController@login_otp');
	Route::post('/registeration-otp', 'API\ApiController@registeration_otp');
	Route::post('/files-upload', 'API\ApiController@files_upload');
	Route::post('/uid-store', 'API\ApiController@uid_store');
	Route::get('/uid-show/{id}', 'API\ApiController@uid_show');
	Route::get('/uid-list', 'API\ApiController@uid_list');
	Route::get('/uid-delete/{id}', 'API\ApiController@uid_delete');
	Route::post('/get-address', 'API\ApiController@get_address');

	Route::post('user-info', 'API\UserApiController@get_details_by_mobile');
	Route::post('create-employee', 'API\UserApiController@create_employee');

	Route::post('self-health-check', 'API\OrderController@post_self_health_check');
	
	Route::post('av-digital-post', 'API\OrderController@post_av_digital');
	Route::post('av-digital', 'API\OrderController@get_user_details');
	Route::post('av-digital-upload-documents', 'API\OrderController@av_digital_upload_documents');

	Route::post('/login-by-email', 'API\UserApiController@login_by_email_pass');
	
	Route::post('/get-survey-info', 'API\SurveyController@show');
	Route::post('/get-survey-details', 'API\SurveyController@details');
	Route::post('/post-survey-answer', 'API\SurveyController@update');
	Route::post('/generate-message', 'API\SurveyController@generate_message');
	Route::post('/create-survey', 'API\SurveyController@store');
	Route::post('/generate-reminder', 'API\SurveyController@generate_runtime_reminder');
	
	Route::middleware('auth:api')->group(function () {
		Route::get('employer-profile', 'API\EmployerController@employer_profile');
		Route::post('update-employer-profile', 'API\EmployerController@update_employer_profile');
		Route::get('my-employees', 'API\UserApiController@my_employees');		
		Route::get('employee-address/{employee_id}', 'API\UserAddressController@employee_address');
		Route::post('add-employee-address', 'API\UserAddressController@add_employee_address');
		Route::post('delete-employee-address/{id}', 'API\UserAddressController@delete_employee_address');		
		Route::get('employer-employee-network', 'API\EmployerController@employer_employee_network');		
		Route::post('scan-employee', 'API\EmployeeController@add_employee_scan');	
		Route::get('employee-profile/{employee_id}', 'API\EmployeeController@employee_profile');	
		Route::post('verification-types', 'API\VerificationTypeController@index');	
		Route::post('add-employers-employee', 'API\EmployeeController@add_employers_employee');	
		Route::post('register-employee', 'API\EmployeeController@add_employers_employee');			
		Route::post('upload-employee-document', 'API\EmployeeController@upload_employee_document');	
		Route::post('upload-employee-photo', 'API\EmployeeController@upload_employee_photo');	
		Route::post('update-employment-info', 'API\EmployeeController@update_employment_info');		
		Route::post('remove-network-employee', 'API\EmployeeController@remove_network_employee');		
		Route::post('post-support', 'API\EmployerController@post_support');		
		Route::post('apply-promocode', 'API\UserApiController@apply_promocode');
		
		Route::post('place-order', 'API\OrderController@store');

		Route::post('register-students', 'API\StudentController@store');

		Route::post('employer-dashboard', 'API\DashboardController@index');
		Route::get('get-candidates', 'API\DashboardController@get_candidates');
		Route::get('get-visitors', 'API\VisitorController@get_visitors');
		Route::post('store-visitors', 'API\VisitorController@store_visitor');		
		Route::post('get-survey', 'API\OrderController@get_survey');
		Route::post('get-survey-data/{id}', 'API\OrderController@get_survey_details');
		
		//import from xls sheet
		Route::post('import-student', 'API\ImportExportController@import')->name('import');

		Route::get('account-info', 'API\EmployerController@get_account_for_b2b');
		Route::post('change-password', 'API\EmployeeController@change_password');
		Route::post('healthcheck-dashboard', 'API\SurveyController@dashboard');
		Route::post('notification','API\DashboardController@notification');
		Route::post('notification-count','API\DashboardController@notificationCount');
		Route::post('seenNotification','API\DashboardController@seenNotification');
	});
});